package com.cloudtech.admob.mediation;

import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.cloudtech.ads.callback.CTAdEventListener;
import com.cloudtech.ads.core.CTNative;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.vo.AdsNativeVO;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.mediation.customevent.CustomEventInterstitial;
import com.google.android.gms.ads.mediation.customevent.CustomEventInterstitialListener;

/**
 * Created by Vincent
 * Email:jingwei.zhang@yeahmobi.com
 */
public class CTCustomEventInterstitial implements CustomEventInterstitial {
    private CTNative result;
    private CustomEventInterstitialListener interstitialListener;

    @Override
    public void requestInterstitialAd(Context context, CustomEventInterstitialListener customEventInterstitialListener, String serverParameter, MediationAdRequest mediationAdRequest, Bundle bundle) {
        interstitialListener = customEventInterstitialListener;
        CTService.preloadInterstitial(serverParameter, true, false, context, ctAdEventListener);
    }


    @Override
    public void showInterstitial() {
        CTService.showInterstitial(result);
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {

    }


    @Override
    public void onResume() {

    }


    private CTAdEventListener ctAdEventListener = new CTAdEventListener() {
        @Override
        public void onAdviewGotAdSucceed(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdLoaded();
            }
            CTCustomEventInterstitial.this.result = result;
        }


        @Override
        public void onAdsVoGotAdSucceed(AdsNativeVO result) {

        }


        @Override
        public void onInterstitialLoadSucceed(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdOpened();
            }
        }


        @Override
        public void onAdviewGotAdFail(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdFailedToLoad(AdRequest.ERROR_CODE_NO_FILL);
            }
        }


        @Override
        public void onAdviewIntoLandpage(CTNative result) {

        }


        @Override
        public void onStartLandingPageFail(CTNative result) {

        }


        @Override
        public void onAdviewDismissedLandpage(CTNative result) {

        }


        @Override
        public void onAdviewClicked(CTNative result) {

        }


        @Override
        public void onAdviewClosed(CTNative result) {
            if (interstitialListener != null) {
                interstitialListener.onAdClosed();
            }
        }


        @Override
        public void onAdviewDestroyed(CTNative result) {

        }
    };
}
