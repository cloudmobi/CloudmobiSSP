package com.cloudtech.admob.mediation;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.cloudtech.ads.callback.VideoAdLoadListener;
import com.cloudtech.ads.core.CTError;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.ads.core.CTVideo;
import com.cloudtech.videoads.core.CTServiceVideo;
import com.cloudtech.videoads.core.VideoAdListener;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdListener;

/**
 * Created by Vincent
 * Email:jingwei.zhang@yeahmobi.com
 */
public class CTRewardedVideoAdapter implements MediationRewardedVideoAdAdapter {

    private static final String TAG = "CTRewardedVideoAdapter";

    private static String slotId = "";

    private MediationRewardedVideoAdListener mAdmobListener;
    private Context context;

    private CTVideo ctVideo;
    private VideoAdListener cloudRVListener = new VideoAdListener() {
        @Override
        public void videoPlayBegin() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdOpened(CTRewardedVideoAdapter.this);
                mAdmobListener.onVideoStarted(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void videoPlayFinished() {

        }


        @Override
        public void videoPlayError(Exception e) {
            if (mAdmobListener != null) {
                mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this, Integer.parseInt(CTError.ERR_CODE_VIDEO));
            }
        }


        @Override
        public void videoClosed() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdClosed(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void onRewardedVideoAdRewarded(final String rewardName, final String rewardAmount) {
            if (mAdmobListener != null) {
                mAdmobListener.onRewarded(CTRewardedVideoAdapter.this, new RewardItem() {
                    @Override
                    public String getType() {
                        return rewardName;
                    }


                    @Override
                    public int getAmount() {
                        int amount = 0;
                        try {
                            amount = Integer.parseInt(rewardAmount);
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                        return amount;
                    }
                });
            }
        }

    };
    private boolean isInitialized;


    @Override
    public void initialize(Context context,
                           MediationAdRequest mediationAdRequest,
                           String unUsed,
                           MediationRewardedVideoAdListener listener,
                           Bundle serverParameters,
                           Bundle mediationExtras) {
        mAdmobListener = listener;
        slotId = serverParameters.getString("parameter");
        CTService.init(context, slotId);
        if (!(context instanceof Activity)) {
            Log.w("CloudmobiAdapter", "Context must be of type Activity.");
            listener.onInitializationFailed(
                CTRewardedVideoAdapter.this, AdRequest.ERROR_CODE_INVALID_REQUEST);
            return;
        }
        this.context = context;
        mAdmobListener.onInitializationSucceeded(CTRewardedVideoAdapter.this);
        isInitialized = true;
    }

    private VideoAdLoadListener loadListener = new VideoAdLoadListener() {
        @Override
        public void onVideoAdLoaded(CTVideo ctVideo) {
            if (ctVideo != null) {
                CTRewardedVideoAdapter.this.ctVideo = ctVideo;
                mAdmobListener.onAdLoaded(CTRewardedVideoAdapter.this);
                return;
            }
            mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this, Integer.parseInt(CTError.ERR_CODE_VIDEO));
        }


        @Override
        public void onVideoAdLoadFailed(CTError ctError) {
            mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this, Integer.parseInt(CTError.ERR_CODE_VIDEO));
        }
    };

    @Override
    public void loadAd(MediationAdRequest mediationAdRequest, Bundle bundle, Bundle bundle1) {
        if (mAdmobListener != null) {
            CTServiceVideo.preloadRewardedVideo(context, slotId, loadListener);
        }
    }


    @Override
    public void showVideo() {
        CTServiceVideo.showRewardedVideo(ctVideo, cloudRVListener);
    }


    @Override
    public boolean isInitialized() {
        return isInitialized;
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {
    }


    @Override
    public void onResume() {

    }

}
