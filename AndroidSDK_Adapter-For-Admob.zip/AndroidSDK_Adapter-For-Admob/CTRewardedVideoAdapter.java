package com.cloudtech.admob.mediation;

import android.app.Activity;
import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import com.cloudtech.ads.core.CTService;
import com.cloudtech.mediationsdk.config.Reward;
import com.cloudtech.mediationsdk.core.CloudmobiSDK;
import com.cloudtech.mediationsdk.core.RewardedVideoListener;
import com.cloudtech.mediationsdk.util.CloudmobiError;
import com.google.android.gms.ads.mediation.MediationAdRequest;
import com.google.android.gms.ads.reward.RewardItem;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdAdapter;
import com.google.android.gms.ads.reward.mediation.MediationRewardedVideoAdListener;

/**
 * Created by Vincent
 * Email:jingwei.zhang@yeahmobi.com
 */
public class CTRewardedVideoAdapter implements MediationRewardedVideoAdAdapter {

    private static final String TAG = "CTRewardedVideoAdapter";

    public static String slotId = "";

    private MediationRewardedVideoAdListener mAdmobListener;

    private RewardedVideoListener cloudRVListener = new RewardedVideoListener() {
        @Override
        public void onRewardedVideoAdOpened() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdOpened(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void onRewardedVideoAdClosed() {
            if (mAdmobListener != null) {
                mAdmobListener.onAdOpened(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void onRewardedVideoAvailabilityChanged(boolean b) {
            if (mAdmobListener != null) {
                if (b) {
                    mAdmobListener.onAdLoaded(CTRewardedVideoAdapter.this);
                } else {
                    mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this, CloudmobiError.ERROR_CODE_NO_ADS_TO_SHOW);
                }
            }
        }


        @Override
        public void onRewardedVideoAdStarted() {
            if (mAdmobListener != null) {
                mAdmobListener.onVideoStarted(CTRewardedVideoAdapter.this);
            }
        }


        @Override
        public void onRewardedVideoAdEnded() {
        }


        @Override
        public void onRewardedVideoAdRewarded(final Reward reward) {
            if (mAdmobListener != null) {
                mAdmobListener.onRewarded(CTRewardedVideoAdapter.this,
                    new RewardItem() {
                        @Override
                        public String getType() {
                            return reward.getmRewardName();
                        }


                        @Override
                        public int getAmount() {
                            return reward.getmRewardAmount();
                        }
                    });
            }
        }


        @Override
        public void onRewardedVideoAdShowFailed(CloudmobiError cloudmobiError) {
            if (mAdmobListener != null) {
                mAdmobListener.onAdFailedToLoad(CTRewardedVideoAdapter.this, cloudmobiError.getErrorCode());
            }
        }
    };


    @Override
    public void initialize(Context context,
                           MediationAdRequest mediationAdRequest,
                           String unUsed,
                           MediationRewardedVideoAdListener listener,
                           Bundle serverParameters,
                           Bundle mediationExtras) {
        mAdmobListener = listener;
        slotId = serverParameters.getString("parameter");
        CTService.init(context, slotId);
        if (!(context instanceof Activity)) {
            Log.w("CloudmobiAdapter", "Context must be of type Activity.");
            return;
        }
        CloudmobiSDK.setRewardedVideoListener(cloudRVListener);
        CloudmobiSDK.initRewardVideo((Activity) context);
        mAdmobListener.onInitializationSucceeded(
            CTRewardedVideoAdapter.this);
    }


    @Override
    public void loadAd(MediationAdRequest mediationAdRequest, Bundle bundle, Bundle bundle1) {
        if (mAdmobListener != null) {
            if (CloudmobiSDK.isRewardedVideoAvailable(slotId)) {
                mAdmobListener.onAdLoaded(this);
            } else {
                mAdmobListener.onAdFailedToLoad(this, CloudmobiError.ERROR_CODE_NO_ADS_TO_SHOW);
            }
        }
    }


    @Override
    public void showVideo() {
        CloudmobiSDK.showRewardedVideo(slotId);
    }


    @Override
    public boolean isInitialized() {
        return false;
    }


    @Override
    public void onDestroy() {

    }


    @Override
    public void onPause() {
    }


    @Override
    public void onResume() {

    }

}
