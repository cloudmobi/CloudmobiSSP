# Integrate Cloudmobi RewardedVideo into Admob



### 1. Setup Cloudmobi account and slot id. 

See: [SDK Integration Guide ](https://github.com/cloudmobi/CloudmobiSSP)

-------



### 2. Create apps and ad unit id in Admob console, as below

> ADD APP

![image](https://user-images.githubusercontent.com/7203578/32546617-5102037a-c445-11e7-85e0-aff096505e7e.png)

> ADD AD UNIT 

![image](https://user-images.githubusercontent.com/7203578/32546656-73167126-c445-11e7-818e-a20e7ea49670.png)

-------



### 3. Create Mediation Group, as below

![image](https://user-images.githubusercontent.com/7203578/32546363-75018e9a-c444-11e7-897b-dfff28811266.png)

------



### 4. Create the related between Cloudmobi slot id and Admob ad unit id, as below

![image](https://user-images.githubusercontent.com/7203578/32546982-63059b44-c446-11e7-97e5-04e4c03f918a.png)

-------



###  5. Add Cloudmobi custom event in Admob console, as below

![image](https://user-images.githubusercontent.com/7203578/32547141-da20e616-c446-11e7-8698-ea61827d4909.png)

![image](https://user-images.githubusercontent.com/7203578/32547248-3a9321bc-c447-11e7-8f41-41d8e383507f.png)

```
Class Name: com.cloudtech.admob.mediation.CTRewardedVideoAdapter (example)
Parameter: 1601 (Cloudmobi slot id)
```

-------



### 6. Copy CTRewardedVideoAdapter.java into your code folder

### Update the AndroidMenifest.xml for Cloudmobi 

```
<!--for cloudmobi rewarded video-->
<activity android:name="com.cloudtech.videoads.view.CTInterstitialActivity"
  android:configChanges="keyboard|keyboardHidden|orientation|screenLayout|uiMode|screenSize|smallestScreenSize"/>
  
<service
    android:name="com.cloudtech.ads.core.AdGuardService"
    android:permission="android.permission.BIND_JOB_SERVICE"/>
```

### 7. Add ProGuard Rules

```
-dontoptimize
-dontpreverify
#for sdk
-dontwarn com.cloudtech.**
-keep public class com.cloudtech.**{*;}
#for gaid
-keep class **.AdvertisingIdClient$** { *; }
#for not group facebook/admob ads
-dontwarn com.google.android.**
-dontwarn com.facebook.ads.**
```


### 8. Admob RewardedVIdeo Integrate 

See this [link](https://developers.google.com/admob/android/rewarded-video)

