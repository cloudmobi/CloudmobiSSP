//
//  CTVideoDelegate.h
//  CTSDK
//
//  Created by 兰旭平 on 2017/2/16.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol CTVideoDelegate <NSObject>
@optional
- (void)CTVideoStartPlay:(UIView *)videoView;
- (void)CTVideoPlayEnd:(UIView *)videoView;
- (void)CTVideoClicked:(UIView *)videoView;
- (void)CTVideoDidLeaveApplication:(UIView *)videoView;
- (void)CTVideoJumpfailed:(UIView *)videoView;
@end
