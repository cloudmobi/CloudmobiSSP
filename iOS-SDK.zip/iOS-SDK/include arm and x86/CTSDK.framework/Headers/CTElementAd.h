//
//  CTElementAd.h
//  CTSDK
//
//  Created by Mirinda on 16/8/12.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CTElementModel.h"

@interface CTElementAd : UIView
@property(nonatomic,strong)CTNativeElementAdModel* adElementmodel;


-(instancetype)init;
-(instancetype)initWithFrame:(CGRect)frame;
@end
