//
//  CTElementAd.h
//  CTSDK
//

#import <UIKit/UIKit.h>
#import "CTElementModel.h"
@protocol CTElementAdDelegate;

@interface CTElementAd : UIView
@property(nonatomic,strong)CTNativeElementAdModel* adElementmodel;
@property(nonatomic, weak)id<CTElementAdDelegate> delegate;

//初始化方法
-(instancetype)init;
-(instancetype)initWithFrame:(CGRect)frame;
@end
