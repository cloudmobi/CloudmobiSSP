//
//  CTManager.h
//  CTSDK
//
//  Created by Mirinda on 16/6/15.
//  Copyright © 2016年 YeahMobi. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CTElementModel.h"

@class CTNativeElementAdModel;

typedef enum : NSUInteger {
    CTImageWHRateOneToOne= 0, //Width:Hight  = 1:1
    CTImageWHRateOnePointNineToOne //Width:Hight  = 1.9:1
}  CTImageWidthHightRate;

@interface CTService : NSObject

//Interstitial AD inferface
//Preload Interstitial
+(void)preloadInterstitialWithSlotId:(NSString*)slot_id
                            delegate:(id)delegate
                            keyWords:(NSString *)keyWords
                              isTest:(BOOL)isTest
                             success:(void (^)(UIView* InterstitialView))success
                             failure:(void (^)(NSError *error))failure;
//Interstitial Show
+(BOOL)interstitialShow;

//Interstitial Close
+(BOOL)interstitialClose;


//Native AD Interface
+(void)getNativeADswithSlotId:(NSString*)slot_id
                     delegate:(id)delegate
                        frame:(CGRect)frame
              needCloseButton:(BOOL)isNeedBtn
                     keyWords:(NSString *)keyWords
                       isTest:(BOOL)isTest
                      success:(void (^)(UIView* NativeView))success
                      failure:(void (^)(NSError *error))failure;



//Banner AD Interface
+(void)getBannerADswithSlotId:(NSString*)slot_id
                     delegate:(id)delegate
                        frame:(CGRect)frame
              needCloseButton:(BOOL)isNeedBtn
                     keyWords:(NSString *)keyWords
                       isTest:(BOOL)isTest
                      success:(void (^)(UIView* bannerView))success
                      failure:(void (^)(NSError *error))failure;

//Element Native AD Interface
+(void)getElementNativeADswithSlotId:(NSString*)slot_id
                            delegate:(id)delegate
                 imageWidthHightRate:(CTImageWidthHightRate)WHRate
                            keyWords:(NSString *)keyWords
                              isTest:(BOOL)isTest
                             success:(void (^)(CTNativeElementAdModel* elementModel))success
                             failure:(void (^)(NSError *error))failure;


@end


