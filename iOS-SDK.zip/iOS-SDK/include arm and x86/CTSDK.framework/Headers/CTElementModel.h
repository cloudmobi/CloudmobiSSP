//
//  CTElementModel.h
//  CTSDK
//
//  Created by 兰旭平 on 16/8/15.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@class CTElementAdListModel,CTNativeElementAdModel,FBMediaView;
@interface CTElementModel : NSObject

@property (nonatomic, strong)NSArray<CTElementAdListModel *> *ad_list;
@property (nonatomic, strong)NSString *err_msg;
@property (nonatomic, assign)NSInteger err_no;

@end


@interface CTElementAdListModel : NSObject

@property (nonatomic, strong)CTNativeElementAdModel *native_adobj;
@property (nonatomic, strong)NSString *adid;
@property (nonatomic, strong)NSString *impid;
@property (nonatomic, assign)NSInteger landing_type;
@property (nonatomic, assign)NSInteger ad_expire_time;
@property (nonatomic, assign)NSInteger pre_click;
@property (nonatomic, strong)NSString *clk_url;
@property (nonatomic, strong)NSArray *clk_tks;
@property (nonatomic, strong)NSArray *imp_tk_url;
@property (nonatomic, strong)NSArray *clk_tk_url;

@end

@interface CTElementAdTransmit : NSObject
@property (nonatomic, strong)NSString *adid;
@property (nonatomic, strong)NSString *impid;
@property (nonatomic, assign)NSInteger landing_type;
@property (nonatomic, assign)NSInteger ad_expire_time;
@property (nonatomic, assign)NSInteger pre_click;
@property (nonatomic, strong)NSString *clk_url;
@property (nonatomic, strong)NSArray *clk_tks;
@property (nonatomic, strong)NSArray *imp_tk_url;
@property (nonatomic, strong)NSArray *clk_tk_url;

@end

@interface CTNativeElementAdModel : NSObject

@property (nonatomic, strong)NSString *icon;
@property (nonatomic, strong)UIImage *iconImage;
@property (nonatomic, strong)NSString *title;
@property (nonatomic, strong)NSString *image;
@property (nonatomic, strong)NSString *desc;
@property (nonatomic, strong)NSString *button;
@property (nonatomic, assign)float star;
@property (nonatomic, strong)NSString *choices_link_url;
@property (nonatomic, assign)NSInteger objCode;
//@property (nonatomic, strong)FBMediaView *fbMView;
@property (nonatomic, strong)UIImage* ADsignImage;
@property (nonatomic, assign)BOOL isFb;
@property (nonatomic, assign)NSInteger inteval;

@end
