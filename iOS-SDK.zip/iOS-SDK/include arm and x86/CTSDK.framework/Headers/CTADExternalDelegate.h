//
//  CTIntersitialPrivate.h
//  CTSDK
//
//  Created by Mirinda on 16/7/26.
//  Copyright © 2016年 YeahMobi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CTInterstitial;
@class CTNative;
@class CTBanner;
//@class CTElement;
@class CTElementAd;

@protocol CTInterstitialDelegate <NSObject>
#pragma mark Interstitial Interaction Notifications

@optional
/**
 * User click the advertisement.
 */
-(void)CTInterstitialDidClick:(CTInterstitial*)interstitialAD;
/**
 * Advertisement landing page will show.
 */
-(void)CTInterstitialDidIntoLandingPage:(CTInterstitial*)interstitialAD;
/**
 * User left the advertisement landing page.
 */
-(void)CTInterstitialDidLeaveLandingPage:(CTInterstitial*)interstitialAD;
/**
 * User close the advertisement.
 */
-(void)CTInterstitialClosed:(CTInterstitial*)interstitialAD;
/**
 * Leave App
 */
-(void)CTInterstitialWillLeaveApplication:(CTInterstitial*)interstitialAD;

@end


@protocol CTNativeDelegate <NSObject>

#pragma mark Interstitial Native Notifications
@optional
/**
 * User click the advertisement.
 */
-(void)CTNativeDidClick:(CTNative*)native;
/**
 * Advertisement landing page will show.
 */
-(void)CTNativeDidIntoLandingPage:(CTNative*)native;
/**
 * User left the advertisement landing page.
 */
-(void)CTNativeDidLeaveLandingPage:(CTNative*)native;
/**
 * User close the advertisement.
 */
-(void)CTNativeClosed:(CTNative*)native;
/**
 * Leave App
 */
-(void)CTNativeWillLeaveApplication:(CTNative*)native;
/**
 * User close the Html5.
 */
-(void)CTNativeHtml5Closed:(CTNative*)native;
@end


#pragma mark Banner delegate

@protocol CTBannerDelegate <NSObject>

@optional
/**
 * User click the advertisement.
 */
-(void)CTBannerDidClick:(CTBanner*)banner;
/**
 * Advertisement landing page will show.
 */
-(void)CTBannerDidIntoLandingPage:(CTBanner*)banner;
/**
 * User left the advertisement landing page.
 */
-(void)CTBannerDidLeaveLandingPage:(CTBanner*)banner;
/**
 * User close the advertisement.
 */
-(void)CTBannerClosed:(CTBanner*)banner;
/**
 * Leave App
 */
-(void)CTBannerWillLeaveApplication:(CTBanner*)banner;
/**
 * User close the Html5.
 */
-(void)CTBannerHtml5Closed:(CTBanner*)banner;
@end

#pragma mark ElementAd Delegate

@protocol CTElementAdDelegate <NSObject>

@optional
/**
 * User click the advertisement.
 */
-(void)CTElementAdDidClick:(CTElementAd *)ElementAd;
/**
 * Advertisement landing page will show.
 */
-(void)CTElementAdDidIntoLandingPage:(CTElementAd *)ElementAd;
/**
 * User left the advertisement landing page.
 */
-(void)CTElementAdDidLeaveLandingPage:(CTElementAd *)ElementAd;
/**
 * Leave App
 */
-(void)CTElementAdWillLeaveApplication:(CTElementAd *)ElementAd;

@end

