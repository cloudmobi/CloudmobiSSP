如果已经使用了1.3.1及其以前的SDK
调用获取元素的getElementNativeADswithSlotId:接口改为：


	CTService *service = [CTService shareManager];
    [service getNativeADswithSlotId:@"260" delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES success:^(CTNativeAdModel *nativeModel) {
        
    } failure:^(NSError *error) {
        
    }];
	调用了获取元素的Native接口之后需要将继承于CTNativeAd的ad视图在请求到广告图片数据成功或失败之后调用adExposure接口,例如[ctview adExposure];
    
    
调用了获取模板的getNativeADswithSlotId:接口的请使用：

	CTService *service = [CTService shareManager];
    [service getNaTemplateADswithSlotId:@"263" delegate:self frame:CGRectMake(20, 150, XPWidth - 40, (XPWidth - 40)/1.9 + 40 )  needCloseButton:YES isTest:YES success:^(UIView *NaTemplateView) {
        
    } failure:^(NSError *error) {
       
    }];

