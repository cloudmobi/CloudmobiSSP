//
//  RewardVideoViewController.m
//  CTSDK_iOS
//
//  Created by 兰旭平 on 2017/3/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "NativeVideoViewController.h"
#import <CTSDK/CTSDK.h>
#import "Tools.h"
#import "NativeVideoTableViewController.h"
#import "XCHudHelper.h"

@interface NativeVideoViewController ()<CTNativeVideoDelegate>
@property (nonatomic, strong)UIView *adView;;
@property (nonatomic, strong) UIButton *loadButton;
@property (nonatomic, strong) UIButton *showAdButton;
@property (nonatomic, strong)UILabel *nvTitleLable;
@property (nonatomic, strong)UILabel* nvDescLable;
@property (nonatomic, strong)UIImageView *nvLogo;
@property (nonatomic, strong)UIImageView *playLogo;
@property (nonatomic, strong)UIImageView *nvBg;
@property (nonatomic, strong)UIButton *nvBtnView;
@property (nonatomic, strong)CTNativeVideoModel *nativeVideoModel;
@property (nonatomic, assign)BOOL viewIsShowed;
@property (nonatomic, strong)CTMediaView *mediaView;
@end

@implementation NativeVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setUILayout];
}

- (void)setUILayout
{
    self.loadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.loadButton.backgroundColor = [UIColor brownColor];
    self.loadButton.frame = CGRectMake(0, XPHeight - kButtonHeight, XPWidth / 2.0, kButtonHeight);
    [self.loadButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.loadButton setTitle:[NSString stringWithFormat:@"Load Ad"] forState:UIControlStateNormal];
    [self.view addSubview:self.loadButton];
    [self.loadButton addTarget:self action:@selector(loadNativeVideo) forControlEvents:UIControlEventTouchUpInside];
    
    self.showAdButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.showAdButton.backgroundColor = [UIColor orangeColor];
    self.showAdButton.frame = CGRectMake(XPWidth / 2.0, XPHeight - kButtonHeight, XPWidth / 2.0, kButtonHeight);
    [self.showAdButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.showAdButton setTitle:[NSString stringWithFormat:@"TableView Ads"] forState:UIControlStateNormal];
    [self.showAdButton addTarget:self action:@selector(showTableViewAds) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.showAdButton];
    
    UIButton* disMissButton = [UIButton buttonWithType:UIButtonTypeSystem];
    disMissButton.frame = CGRectMake(0, XPHeight - 2 * kButtonHeight, XPWidth, kButtonHeight);
    disMissButton.backgroundColor = [UIColor grayColor];
    [disMissButton setTitle:@"Dismiss ViewController" forState:UIControlStateNormal];
    [disMissButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:disMissButton];
}

- (void)showTableViewAds
{
    NativeVideoTableViewController *vc = [[NativeVideoTableViewController alloc] init];
    [self presentViewController:vc animated:YES completion:nil];
}
- (void)loadNativeVideo
{
    [[CTService shareManager] getNativeVideoADswithSlotId:NativeVideoSlotId delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES];
    [[XCHudHelper sharedInstance] showHudAcitivityOnWindow];
}

- (void)dismiss
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)setButtonState:(UIButton *)button allowToclick:(BOOL)state
{
    if ([NSThread isMainThread]) {
        button.alpha = state ? 1 : 0.3;
        button.userInteractionEnabled = state;
    }else {
        dispatch_sync(dispatch_get_main_queue(), ^{
            button.alpha = state ? 1 : 0.3;
            button.userInteractionEnabled = state;
        });
    }
}

- (void)getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}

#pragma mark - Delegate for RewardVideo (CT)
-(void)viewWillAppear:(BOOL)animated{
    self.viewIsShowed = YES;
    [self.nativeVideoModel.videoViewController playVideo];
}

-(void)viewWillDisappear:(BOOL)animated{
    [self.nativeVideoModel.videoViewController stopVideo];
}

-(void)CTNativeVideoLoadSuccess:(CTNativeVideoModel *)nativeVideoModel{
    [[XCHudHelper sharedInstance] hideHud];
    [self.adView removeFromSuperview];
    [self.adView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    self.view.backgroundColor = [UIColor whiteColor];
    
    NSInteger titleHeight = 25;
    //视频比例1:1.77
    NSInteger movieViewHeight = self.view.frame.size.width / 1.77;
    NSInteger descHeight = 30;
    NSInteger y = [[UIApplication sharedApplication] statusBarFrame].size.height + self.navigationController.navigationBar.frame.size.height;
    self.adView = [[UIView alloc] initWithFrame:CGRectMake(0, y, self.view.frame.size.width, titleHeight + movieViewHeight + descHeight)];
    [self.view addSubview:self.adView];
    //数据
    self.nativeVideoModel = nativeVideoModel;
    
    //label
    self.nvTitleLable = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, self.adView.frame.size.width, 25)];//标题
    self.nvTitleLable.font = [UIFont systemFontOfSize:18];
    self.nvTitleLable.textColor = [UIColor blackColor];
    self.nvTitleLable.text = nativeVideoModel.title;
    [self.adView addSubview:self.nvTitleLable];
    
    //desc
    self.nvDescLable = [[UILabel alloc]initWithFrame:CGRectMake(25, self.adView.frame.size.height - 25, self.adView.frame.size.width - 100, 25)];//标题
    self.nvDescLable.font = [UIFont systemFontOfSize:12];
    self.nvDescLable.textColor = [UIColor grayColor];
    self.nvDescLable.text = nativeVideoModel.desc;
    [self.adView addSubview:self.nvDescLable];
    
    //ad logo
    self.nvLogo = [[UIImageView alloc]initWithFrame:CGRectMake(5, self.adView.frame.size.height - 20, 16, 16)];
    self.nvLogo.image = self.nativeVideoModel.ADsignImage;
    [self.adView addSubview:self.nvLogo];
    
    //media view, width:height = 1.77:1
    self.mediaView = [[CTMediaView alloc] initWithFrame:CGRectMake(0, 30, self.adView.frame.size.width, self.adView.frame.size.width/1.77)];
    [self.adView addSubview:self.mediaView];
    self.mediaView.WWANPlayEnabled = YES;
    self.mediaView.autoplayEnabled = YES;
    [self.mediaView setNativeVideoAd:nativeVideoModel];

    //button view
    self.nvBtnView = [[UIButton alloc] initWithFrame:CGRectMake(self.adView.frame.size.width - 65, self.adView.frame.size.height - 24, 60, 20)];
    self.nvBtnView.layer.borderColor = [[UIColor blueColor] CGColor];
    self.nvBtnView.layer.borderWidth = 1;
    self.nvBtnView.layer.cornerRadius = 5;
    [self.adView addSubview:self.nvBtnView];
    
    //button label
    [self.nvBtnView setTitle:nativeVideoModel.button forState:UIControlStateNormal];
    [self.nvBtnView setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    self.nvBtnView.titleLabel.font = [UIFont systemFontOfSize:12];

    //button gesture
    UITapGestureRecognizer *downloadGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(downloadBtnClick)];
    downloadGesture.numberOfTapsRequired = 1;
    downloadGesture.numberOfTouchesRequired = 1;
    [self.nvBtnView addGestureRecognizer:downloadGesture];
    
    //click gesture
    UITapGestureRecognizer *jumpGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickAD)];
    jumpGesture.numberOfTapsRequired = 1;
    jumpGesture.numberOfTouchesRequired = 1;
    [self.mediaView addGestureRecognizer:jumpGesture];
    
    UITapGestureRecognizer *jumpGesture1 = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(clickAD)];
    jumpGesture.numberOfTapsRequired = 1;
    jumpGesture.numberOfTouchesRequired = 1;
    self.nvBg.userInteractionEnabled = YES;
    [self.nvBg addGestureRecognizer:jumpGesture1];
}

-(void)CTNativeVideoLoadFailed:(NSError *)error{
    dispatch_async(dispatch_get_main_queue(), ^{
        [[XCHudHelper sharedInstance] hideHud];
    });
    
    NSString *errmsg = [[NSString alloc] initWithFormat:@"error no: %ld, err msg: %@", (long)error.code, error.description];
    NSLog(@"errormsg: %@", errmsg);
}

- (void)clickAD{
//    [self.nativeVideoModel clickToPushOnParentVC:self animated:YES];
    [self.nativeVideoModel clickToPresentOnParentVC:self animated:YES completion:nil];
}

- (void)downloadBtnClick{
    [self.nativeVideoModel clickDownload];
}
@end

