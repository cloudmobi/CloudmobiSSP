//
//  Tools.h
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2016/12/27.
//  Copyright © 2016年 com.algorithms.lxp. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZCJHUD.h"

#define kScreenWidth   [UIScreen mainScreen].bounds.size.width
#define kScreenHeight  [UIScreen mainScreen].bounds.size.height
#define XPWidth                 self.view.frame.size.width
#define XPHeight                self.view.frame.size.height
#define kButtonHeight   50

@interface Tools : NSObject
@property (nonatomic, strong)ZCJHUD *hud;
//solve block Circular referencT
#ifndef    weakify
#if __has_feature(objc_arc)

#define weakify( x ) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wshadow\"") \
autoreleasepool{} __weak __typeof__(x) __weak_##x##__ = x; \
_Pragma("clang diagnostic pop")

#else

#define weakify( x ) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wshadow\"") \
autoreleasepool{} __block __typeof__(x) __block_##x##__ = x; \
_Pragma("clang diagnostic pop")

#endif
#endif

#ifndef    strongify
#if __has_feature(objc_arc)

#define strongify( x ) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wshadow\"") \
try{} @finally{} __typeof__(x) x = __weak_##x##__; \
_Pragma("clang diagnostic pop")

#else

#define strongify( x ) \
_Pragma("clang diagnostic push") \
_Pragma("clang diagnostic ignored \"-Wshadow\"") \
try{} @finally{} __typeof__(x) x = __block_##x##__; \
_Pragma("clang diagnostic pop")

#endif
#endif

//解决真机调试不打印log的问题
#ifdef DEBUG
#define XPLog(format, ...) printf("[%s] %s [第%d行] %s\n", __TIME__, __FUNCTION__, __LINE__, [[NSString stringWithFormat:format, ## __VA_ARGS__] UTF8String]);
#else
#define XPLog(format, ...)
#endif

/*CT slot id*/
#define bannerSlotId            @"260"
#define interstitilaSlotId      @"262"
#define nativeSlotId            @"263"
#define AppWallSlotId           @"260"
#define OneNativeSlotId         @"260"
#define TwoNativeSlotId         @"260"
#define KeywordsSlotId          @"260"
#define NativeVideoSlotId       @"34198274"
@end

