//
//  NativeVideoTableViewController.m
//  CTSDK_iOS
//
//  Created by yeahmobi on 2018/3/9.
//  Copyright © 2018年 Mirinda. All rights reserved.
//

#import "NativeVideoTableViewController.h"
#import "NativeVideoTableViewCell.h"
#import "XCHudHelper.h"
#import "Tools.h"

@interface NativeVideoTableViewController () <CTNativeVideoDelegate>
@property (nonatomic, assign) BOOL tableViewLoadFinish;
@property (nonatomic, strong) NSMutableArray* modelArray;
@end

@implementation NativeVideoTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.tableView registerClass:[NativeVideoTableViewCell class] forCellReuseIdentifier:@"NativeVideoCell"];
    
    self.modelArray = [[NSMutableArray alloc] init];
    
    for (int i = 0 ; i < 5 ; i++){
        [[CTService shareManager] getNativeVideoADswithSlotId:NativeVideoSlotId delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES];
    }
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, XPWidth, kButtonHeight)];
    [self.tableView setTableHeaderView:headerView];
    
    UIButton *dismissBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, XPWidth, kButtonHeight)];
    dismissBtn.backgroundColor = [UIColor grayColor];
    [dismissBtn setTitle:@"Dismiss ViewController" forState:UIControlStateNormal];
    [dismissBtn addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [headerView  addSubview:dismissBtn];
}

- (void)dismiss{
    [self dismissViewControllerAnimated:self completion:nil];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated{
    //从其他ui切换回tableview时，需要处理可见cell播放视频
    NSArray * array = [self.tableView indexPathsForVisibleRows];
    for (NSIndexPath* path in array) {
        UITableViewCell *cell = [self.tableView cellForRowAtIndexPath:path];
        if([cell isKindOfClass:[NativeVideoTableViewCell class]]){
            NativeVideoTableViewCell *nvCell = (NativeVideoTableViewCell *)cell;
            [nvCell.model.videoViewController playVideo];
        }
    }
}

#pragma mark - native video delegate
-(void)CTNativeVideoLoadSuccess:(CTNativeVideoModel *)nativeVideoModel{
    [self.modelArray addObject:nativeVideoModel];
    [self.tableView reloadData];
}

-(void)CTNativeVideoLoadFailed:(NSError *)error{
    NSString *errmsg = [[NSString alloc] initWithFormat:@"error no: %ld, err msg: %@", (long)error.code, error.domain];

    dispatch_async(dispatch_get_main_queue(), ^{
        [[XCHudHelper sharedInstance] showHudOnView:self.view caption:errmsg image:nil acitivity:NO autoHideTime:2.0f];
    });
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.modelArray count];
}

- (void)getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NativeVideoTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"NativeVideoCell"];
    //数据
    CTNativeVideoModel * nativeVideoModel = [self.modelArray objectAtIndex:indexPath.row];
    [cell.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    cell.model = nativeVideoModel;
    cell.tableViewController = self;
    
    //label
    cell.nvTitleLable = [[UILabel alloc]initWithFrame:CGRectMake(10, 5, self.view.frame.size.width, 25)];//标题
    cell.nvTitleLable.font = [UIFont systemFontOfSize:18];
    cell.nvTitleLable.textColor = [UIColor blackColor];
    cell.nvTitleLable.text = nativeVideoModel.title;
    [cell addSubview:cell.nvTitleLable];
    
    //desc
    cell.nvDescLable = [[UILabel alloc]initWithFrame:CGRectMake(25, [self getCellHeight] - 30, self.view.frame.size.width - 100, 30)];//标题
    cell.nvDescLable.font = [UIFont systemFontOfSize:12];
    cell.nvDescLable.textColor = [UIColor grayColor];
    cell.nvDescLable.text = nativeVideoModel.desc;
    [cell addSubview:cell.nvDescLable];
    
    //logo
    cell.nvLogo = [[UIImageView alloc]initWithFrame:CGRectMake(5, [self getCellHeight] - 25, 16, 16)];
    cell.nvLogo.image = nativeVideoModel.ADsignImage;
    [cell addSubview:cell.nvLogo];
    
    //background比例同视频 1:1.77
    cell.nvBg = [[UIImageView alloc]initWithFrame:CGRectMake(0, 30, self.view.frame.size.width, self.view.frame.size.width/1.77)];
    
    //如果sdk缓存好图片，直接使用，否则使用url请求图片
    if(nativeVideoModel.AdImage != nil)
        cell.nvBg.image = nativeVideoModel.AdImage;
    else
        [self getImageFromURL:nativeVideoModel.image img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                cell.nvBg.image = ig;
            });
        }];
    [cell addSubview:cell.nvBg];
    
    //wifi下，添加movie view
    if ([[CTService shareManager] isWifi] == YES){
        [nativeVideoModel.videoViewController setFrame:CGRectMake(0, 30, self.view.frame.size.width, self.view.frame.size.width/1.77)];
        [cell addSubview:nativeVideoModel.videoViewController.view];
    }else{
        //play logo
        cell.playLogo = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 61, 61)];
        cell.playLogo.center = cell.nvBg.center;
        cell.playLogo.image = nativeVideoModel.playBtnImage;
        [cell addSubview:cell.playLogo];
    }
    
    //download button view
    cell.nvBtnView = [UIButton buttonWithType:UIButtonTypeCustom];
    cell.nvBtnView.frame = CGRectMake(self.view.frame.size.width - 65, [self getCellHeight] - 25, 60, 20);
    cell.nvBtnView.layer.borderColor = [[UIColor blueColor] CGColor];
    cell.nvBtnView.layer.borderWidth = 1;
    cell.nvBtnView.layer.cornerRadius = 5;
    [cell addSubview:cell.nvBtnView];
    
    //download button label
    [cell.nvBtnView setTitle:nativeVideoModel.button forState:UIControlStateNormal];
    [cell.nvBtnView setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
    cell.nvBtnView.titleLabel.font = [UIFont systemFontOfSize:12];
    
    //click gesture
    [cell addClickGesture];
    return cell;
}

//通过滑动监测新显示出来的cell，做曝光处理
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    //tableview加载好之后，得到当前显示的cell，发送曝光
    if(self.tableViewLoadFinish == YES){
        NSArray * array = [self.tableView indexPathsForVisibleRows];
        for (NSIndexPath* path in array) {
            NativeVideoTableViewCell *cell = [self.tableView cellForRowAtIndexPath:path];
            if([cell isKindOfClass:[NativeVideoTableViewCell class]]){
                NativeVideoTableViewCell *nvCell = (NativeVideoTableViewCell *)cell;
                [nvCell.model impressionForAd];
            }
        }
    }
}

//willDisplayCell和didEndDisplayingCell 配合处理刚打开页面时，有哪些cell可见，并对cell做标记，等广告请求回来时，处理播放和曝光
- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath{
    if ([cell isKindOfClass:[NativeVideoTableViewCell class]]){
        NativeVideoTableViewCell *nvCell = (NativeVideoTableViewCell *)cell;
        nvCell.isShowed = YES;
        [nvCell.model.videoViewController playVideo];
    }
    
    //等待tableview加载完最后一个cell
    if([indexPath row] == ((NSIndexPath*)[[tableView indexPathsForVisibleRows] lastObject]).row){
        self.tableViewLoadFinish = YES;
    }
}

//cell隐藏时，设置状态为不可播放
- (void)tableView:(UITableView *)tableView didEndDisplayingCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath*)indexPath{
    if ([cell isKindOfClass:[NativeVideoTableViewCell class]]){
        NativeVideoTableViewCell *nvCell = (NativeVideoTableViewCell *)cell;
        nvCell.isShowed = NO;
        [nvCell.model.videoViewController stopVideo];
    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return [self getCellHeight];
}

- (CGFloat)getCellHeight{
    NSInteger titleHeight = 30;
    //视频比例1:1.77
    NSInteger movieViewHeight = self.view.frame.size.width / 1.77;
    NSInteger descHeight = 30;
    return titleHeight + movieViewHeight + descHeight;
}

@end
