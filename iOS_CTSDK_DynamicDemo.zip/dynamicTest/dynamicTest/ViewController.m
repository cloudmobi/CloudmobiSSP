

#import "ViewController.h"
#import <CTSDK/CTService.h>
#import <CTSDK/CTADExternalDelegate.h>
#import "CTView.h"
@import FBAudienceNetwork;
@interface ViewController ()<CTNativeAdDelegate>
@property (nonatomic, strong)CTView *nativeView;
@end

@implementation ViewController
@synthesize nativeView;
- (void)viewDidLoad {
    [super viewDidLoad];
  
}
- (IBAction)getCTNativeAd:(id)sender
{
    CTService *service = [CTService shareManager];
    [service getNativeADswithSlotId:@"260" delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES success:^(CTNativeAdModel *nativeModel) {
        nativeView = [[CTView alloc]initWithFrame:CGRectMake(30, 30, self.view.frame.size.width - 60, 200)];
        nativeView.delegate = self;
        
        nativeView.adNativeModel = nativeModel;
        
        [nativeView adExposure];//一定要在nativeView.adNativeModel = nativeModel之后调用广告曝光
        nativeView.titleLable.text = nativeModel.title;
        [self getImageFromURL:nativeModel.icon img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                nativeView.iconImage.image = ig;
            });
        }];
        [self getImageFromURL:nativeModel.image img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                nativeView.imageImage.image = ig;
            });
        }];
        
        nativeView.descLable.text = nativeModel.desc;
        [nativeView.button setTitle:nativeModel.button forState:UIControlStateNormal];
        nativeView.starLable.text = [NSString stringWithFormat:@"%f",nativeModel.star];
        nativeView.logoImage.image = nativeModel.ADsignImage;
        [self.view addSubview:nativeView];
        UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
        btn31.frame = CGRectMake(0 , 160, 100, 40);
        btn31.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];;
        [btn31 setTitle:@"关闭" forState:UIControlStateNormal];
        [btn31 addTarget:self action:@selector(closeElement) forControlEvents:UIControlEventTouchUpInside];
        [nativeView addSubview:btn31];
    } failure:^(NSError *error) {
        NSLog(@" element:这是怎么回事啊，怎么错啊！%@",error.description);
    }];
}

-(void)closeElement
{
    [nativeView removeFromSuperview];
    nativeView.adNativeModel = nil;
    nativeView = nil;
}
#pragma mark - 图片加载方法
-(void) getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}

#pragma mark - Delegate Methods
-(void)CTNativeAdDidClick:(UIView *)nativeAd;
{
    NSLog(@"CTNativeAdDidClick");
}

-(void)CTNativeAdDidIntoLandingPage:(UIView *)nativeAd;
{
    NSLog(@"CTNativeAdDidIntoLandingPage");
}
-(void)CTNativeAdDidLeaveLandingPage:(UIView *)nativeAd;
{
    NSLog(@"CTNativeAdDidLeaveLandingPage");
}

-(void)CTNativeAdWillLeaveApplication:(UIView *)nativeAd;
{
    NSLog(@"CTNativeAdWillLeaveApplication");
}

@end
