//
//  ViewController.swift
//  swiftCallOC
//
//  Created by Mirinda on 17/8/8.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        let manager = CTService.shareManager()
        
        manager?.loadRequestGetCTSDKConfig(bySlot_id:"260")
        manager?.getBannerADswithSlotId("260", delegate: self
            , frame: CGRect.init(origin: CGPoint.init(x: 20, y:20), size: CGSize.init(width: 320, height: 90)), needCloseButton: false, isTest:false, success: { (AnyObject) in
                self.view.addSubview(AnyObject!)
            }, failure: { (AnyObject) in
                
        })
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

