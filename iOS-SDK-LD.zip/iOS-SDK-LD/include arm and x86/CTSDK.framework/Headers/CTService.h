//
//  CTManager.h
//  CTSDK
//
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "CTElementModel.h"
@class CTNativeAdModel;

typedef enum : NSUInteger {
    CTImageWHRateOneToOne= 0, //Width:Hight  = 1:1
    CTImageWHRateOnePointNineToOne //Width:Hight  = 1.9:1
}  CTImageWidthHightRate;

@interface CTService : NSObject
//You should pass the singleton method to create the object, then calls the requests of the different types of ads.
+(instancetype)shareManager;

//Interstitial AD inferface
//Preload Interstitial
-(void)preloadInterstitialWithSlotId:(NSString *)slot_id
                            delegate:(id)delegate
                        isFullScreen:(BOOL)isFull
                              isTest:(BOOL)isTest
                             success:(void (^)(UIView *InterstitialView))success
                             failure:(void (^)(NSError *error))failure;
//Interstitial Show
-(BOOL)interstitialShow;

//Interstitial Screen Direction
-(void)ScreenIsVerticalScreen:(BOOL)isVerticalScreen;

//Interstitial Close
-(BOOL)interstitialClose;


//Native AD Interface
-(void)getNaTemplateADswithSlotId:(NSString *)slot_id
                     delegate:(id)delegate
                        frame:(CGRect)frame
              needCloseButton:(BOOL)isNeedBtn
                       isTest:(BOOL)isTest
                      success:(void (^)(UIView *NaTemplateView))success
                      failure:(void (^)(NSError *error))failure;



//Banner AD Interface
-(void)getBannerADswithSlotId:(NSString *)slot_id
                     delegate:(id)delegate
                        frame:(CGRect)frame
              needCloseButton:(BOOL)isNeedBtn
                       isTest:(BOOL)isTest
                      success:(void (^)(UIView *bannerView))success
                      failure:(void (^)(NSError *error))failure;


//Element Native AD Interface
-(void)getNativeADswithSlotId:(NSString *)slot_id
                            delegate:(id)delegate
                 imageWidthHightRate:(CTImageWidthHightRate)WHRate
                              isTest:(BOOL)isTest
                             success:(void (^)(CTNativeAdModel *nativeModel))success
                             failure:(void (^)(NSError *error))failure;



//Element Native keyWords AD Interface
-(void)getNativeADswithSlotId:(NSString *)slot_id
                            delegate:(id)delegate
                 imageWidthHightRate:(CTImageWidthHightRate)WHRate
                               adcat:(NSInteger)cat
                            keyWords:(NSArray *)keyWords
                              isTest:(BOOL)isTest
                             success:(void (^)(CTNativeAdModel *nativeModel))success
                             failure:(void (^)(NSError *error))failure;

//Multiterm Element Native AD Interface
-(void)getMultitermNativeADswithSlotId:(NSString *)slot_id
                                    adNumbers:(NSInteger)num
                                     delegate:(id)delegate
                          imageWidthHightRate:(CTImageWidthHightRate)WHRate
                                       isTest:(BOOL)isTest
                                      success:(void (^)(NSArray *nativeArr))success
                                      failure:(void (^)(NSError *error))failure;


//Get App Wall View
-(UIViewController *)showAppWallViewController;

-(void)preloadAppWallWithSlotID:(NSString *)slot_id
                customColor:(CTCustomColor *)customColor
                   delegate:(id)delegate
                     isTest:(BOOL)isTest
                    success:(void(^)())success
                    failure:(void(^)(NSError *error))failure;


//Get SDK Version
-(NSString*)getSDKVersion;

@end


