
#import "ViewController.h"
#import <CTSDK/CTService.h>
#import <CTSDK/CTNativeAd.h>
#import "CTView.h"
#import <CTSDK/CTADExternalDelegate.h>
#import "ZCJHUD.h"

@import GoogleMobileAds;
@import FBAudienceNetwork;

@interface ViewController () <CTNativeAdDelegate,CTAppWallDelegate>
@property (nonatomic, assign)BOOL isPushOrPresent;
@property (nonatomic, strong)CTView *ccview;
@property (nonatomic, strong)CTView *cview;
@property (nonatomic, strong)CTView *cview1;
@property (nonatomic, strong)ZCJHUD *hud;
@property (nonatomic, strong)UILabel *descLable;
@property (nonatomic, strong)CTView *keywordsView;
@end
#pragma mark - 请求ID  元素广告类型使用nativeid
/*GP优先*/
//#define bannerSlotId            @"266"
//#define interstitilaSlotId      @"267"
//#define nativeSlotId            @"268"
///*FB优先*/
//#define bannerSlotId            @"261"
//#define interstitilaSlotId      @"264"
//#define nativeSlotId            @"265"
/*CT优先*/
#define bannerSlotId            @"260"
#define interstitilaSlotId      @"262"
#define nativeSlotId            @"263"

#define XPWidth                 self.view.frame.size.width
#define XPHeight                self.view.frame.size.height

@implementation ViewController
@synthesize ccview;
@synthesize cview;
@synthesize cview1;
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    
    self.view.backgroundColor = [UIColor grayColor];
    [self createSubButtonsClickGetAds];
    _isPushOrPresent = NO;
    
    XPLog(@"CTSDK Version:%@",[[CTService shareManager] getSDKVersion]);
    XPLog(@"GoogleSDK Version:%s",GoogleMobileAdsVersionString);
    XPLog(@"FacebookSDK Version:%@",FB_AD_SDK_VERSION);
    /*
    [CTAnalysisService analysisWithSlot_id:@"260"];
     */
}
#pragma mark - 创建创建广告的BUTTON
- (void)createSubButtonsClickGetAds
{
    UIButton* btn = [UIButton buttonWithType:UIButtonTypeSystem];
    btn.frame = CGRectMake(0, XPHeight - 40, XPWidth/6, 40);
    btn.backgroundColor = [UIColor colorWithRed:128/255.0 green:138/255.0 blue:135/255.0 alpha:1];
    [btn setTitle:@"Banner" forState:UIControlStateNormal];
    [btn setTitle:@"GET" forState:UIControlStateSelected];
    [btn addTarget:self action:@selector(getCTBannerViewController) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn];
    
    
    UIButton* btn1 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn1.frame = CGRectMake(XPWidth/6, XPHeight - 40, XPWidth/6, 40);
    btn1.backgroundColor = [UIColor colorWithRed:250/255.0 green:235/255.0 blue:215/255.0 alpha:1];
    [btn1 setTitle:@"Insert" forState:UIControlStateNormal];
    [btn1 addTarget:self action:@selector(getCTInterstitialViewController) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn1];
    
    
    UIButton* btn2 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn2.frame = CGRectMake(XPWidth/6 * 2, XPHeight - 40, XPWidth/6, 40);
    btn2.backgroundColor = [UIColor colorWithRed:135/255.0 green:206/255.0 blue:235/255.0 alpha:1];
    [btn2 setTitle:@"Natemplate" forState:UIControlStateNormal];
    [btn2 addTarget:self action:@selector(getCTNativeViewController) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn2];
    
    
    UIButton* btn3 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn3.frame = CGRectMake(XPWidth/6 * 3, XPHeight - 40, XPWidth/6, 40);
    btn3.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];;
    [btn3 setTitle:@"1-Native" forState:UIControlStateNormal];
    [btn3 addTarget:self action:@selector(getCTOne_ElementViewController) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn3];
    
    
    UIButton* btn4 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn4.frame = CGRectMake(XPWidth/6 * 4, XPHeight - 40, XPWidth/6, 40);
    btn4.backgroundColor = [UIColor colorWithRed:250/255.0 green:128/255.0 blue:114/255.0 alpha:1];;
    [btn4 setTitle:@"2-Native" forState:UIControlStateNormal];
    [btn4 addTarget:self action:@selector(getCTMany_ElementViewController) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn4];
    
    UIButton* btn5 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn5.frame = CGRectMake(XPWidth/6 * 5, XPHeight - 40, XPWidth/6, 40);
    btn5.backgroundColor = [UIColor colorWithRed:0/255.0 green:199/255.0 blue:140/255.0 alpha:1];
    [btn5 setTitle:@"AppWall" forState:UIControlStateNormal];
    [btn5 addTarget:self action:@selector(getCTAppWallViewController) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn5];
    
    UIButton* btn6 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn6.frame = CGRectMake(0, XPHeight - 80, XPWidth/6, 40);
    btn6.backgroundColor = [UIColor colorWithRed:0/255.0 green:199/255.0 blue:140/255.0 alpha:1];
    [btn6 setTitle:@"Keyword" forState:UIControlStateNormal];
    [btn6 setTitle:@"GET" forState:UIControlStateSelected];
    [btn6 addTarget:self action:@selector(getKeywordsAds) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn6];
    
    self.descLable = [[UILabel alloc]init];
    self.descLable.frame = CGRectMake(XPWidth/6.0, XPHeight - 80,XPWidth - XPWidth/6, 40);
    self.descLable.numberOfLines = 0;
    self.descLable.textColor = [UIColor whiteColor];
    self.descLable.textAlignment = NSTextAlignmentCenter;
    [self.view addSubview:self.descLable];
    
    
    UIButton* btn7 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn7.frame = CGRectMake(0, 30, 100, 40);
    btn7.backgroundColor = [UIColor colorWithRed:0/255.0 green:199/255.0 blue:140/255.0 alpha:1];
    [btn7 setTitle:@"SHOWAW" forState:UIControlStateNormal];
    [btn7 setTitle:@"GET" forState:UIControlStateSelected];
    [btn7 addTarget:self action:@selector(ssshwo) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn7];
}
- (void)ssshwo
{
    [self presentViewController:[[CTService shareManager] showAppWallViewController] animated:YES completion:nil];
}
#pragma mark - 获取keywords广告
- (void)getKeywordsAds
{
    [self showGetAd];
    @weakify(self)
    CTService *service = [CTService shareManager];
    [service getNativeADswithSlotId:@"260" delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne adcat:1 keyWords:@[@"games"] isTest:YES success:^(CTNativeAdModel *nativeModel) {
        @strongify(self)
        self.keywordsView = [[CTView alloc]initWithFrame:CGRectMake(30, 30, XPWidth -60, 200)];
        self.keywordsView.delegate = self;
        self.keywordsView.adNativeModel = nativeModel;
        self.keywordsView.titleLable.text = nativeModel.title;
        [self getImageFromURL:nativeModel.icon img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.keywordsView.iconImage.image = ig;
            });
        }];
        [self getImageFromURL:nativeModel.image img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                self.keywordsView.imageImage.image = ig;
            });
        }];
        
        self.keywordsView.descLable.text = nativeModel.desc;
        [self.keywordsView.button setTitle:nativeModel.button forState:UIControlStateNormal];
        self.keywordsView.starLable.text = [NSString stringWithFormat:@"%f",nativeModel.star];
        self.keywordsView.logoImage.image = nativeModel.ADsignImage;
        [self.view addSubview:self.keywordsView];
        UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
        btn31.frame = CGRectMake(50, 100, 100, 40);
        btn31.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];;
        [btn31 setTitle:@"关闭" forState:UIControlStateNormal];
        [btn31 addTarget:self action:@selector(closeKeywords) forControlEvents:UIControlEventTouchUpInside];
        [self.keywordsView addSubview:btn31];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = @"Keywords Ad 获取成功";
        });
    } failure:^(NSError *error) {
        XPLog(@"keywords ad error:%@",error.description);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = [NSString stringWithFormat:@"Keywords Ad 获取失败:%@",error.description];
        });
    }];
    
}
- (void)closeKeywords
{
    [self.keywordsView removeFromSuperview];
    self.keywordsView.adNativeModel = nil;
    self.keywordsView = nil;
}
#pragma mark - 获取CT AppWall
- (void)getCTAppWallViewController
{
    //Custom UI
    [self showGetAd];
    CTCustomColor *customUI ;
    if (_isPushOrPresent)
    {
        customUI = [[CTCustomColor alloc]init];
        customUI.normlBackgroundColor = [UIColor whiteColor];
        customUI.buttonBackgroundColor = [UIColor redColor];
        customUI.normlBackgroundColor = [UIColor yellowColor];
        customUI.btnNormlTextColor = [UIColor yellowColor];
        customUI.btnSelectedTextColor = [UIColor greenColor];
        customUI.cellBackgroundColor = [UIColor grayColor];
        customUI.cellTitleColor = [UIColor purpleColor];
        customUI.cellHeadTitleColor = [UIColor blueColor];
        customUI.marketColor = [UIColor blueColor];
        customUI.sliderViewColor = [UIColor grayColor];
    }
    CTService *service = [CTService shareManager];
    [service preloadAppWallWithSlotID:@"260" customColor:nil delegate:self isTest:YES success:^() {
        NSLog(@"preloadAppWallWithSlotID Success");
        [self presentViewController:[service showAppWallViewController] animated:YES completion:nil];
    } failure:^(NSError *error) {
        NSLog(@"%@",error.description);
    }];
}
#pragma mark - 获取CT Banner
- (void)getCTBannerViewController
{
    [self showGetAd];
    @weakify(self)
    CTService *service = [CTService shareManager];
    [service getBannerADswithSlotId:bannerSlotId delegate:self frame:CGRectMake(20, 150, XPWidth-40 , 50) needCloseButton:YES isTest:YES success:^(UIView *bannerView) {
        @strongify(self)
        [self.view addSubview:bannerView];
    } failure:^(NSError *error) {
        NSString *str = [NSString stringWithFormat:@"Banner出错了：%@",error.description];
        XPLog(@"%@",str);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = str;
        });
    }];
}

#pragma mark - 获取CT Interstitial
- (void)getCTInterstitialViewController
{
    [self showGetAd];
    @weakify(self)
    CTService *service = [CTService shareManager];
    NSLog(@"%@",[service getSDKVersion]);
    [service preloadInterstitialWithSlotId:interstitilaSlotId delegate:self isFullScreen:YES isTest:YES success:^(UIView *InterstitialView) {
        @strongify(self)
//        [self.view addSubview:InterstitialView];
//        [service interstitialShow];
        [service interstitialShowWithControllerStyle];
    } failure:^(NSError *error) {
        NSString *str = [NSString stringWithFormat:@"Interstital出错了：%@",error.description];
        XPLog(@"%@",str);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = str;
        });
    }];
}
#pragma mark - 获取CT Native
- (void)getCTNativeViewController
{
    [self showGetAd];
    @weakify(self)
    CTService *service = [CTService shareManager];
    [service getNaTemplateADswithSlotId:nativeSlotId delegate:self frame:CGRectMake(20, 150, XPWidth - 40, (XPWidth - 40)/1.9 + 40 )  needCloseButton:YES isTest:YES success:^(UIView *NaTemplateView) {
        @strongify(self)
        [self.view addSubview:NaTemplateView];
    } failure:^(NSError *error) {
        NSString *str = [NSString stringWithFormat:@"Native出错了：%@",error.description];
        XPLog(@"%@",str);
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = str;
        });
    }];
}
#pragma mark - 获取CT One Element
- (void)getCTOne_ElementViewController
{
    @weakify(self)
    CTService *service = [CTService shareManager];
    [service getNativeADswithSlotId:nativeSlotId delegate:self imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES success:^(CTNativeAdModel *nativeModel) {
        @strongify(self)
        ccview = [[CTView alloc]initWithFrame:CGRectMake(30, 30, XPWidth -60, 200)];
        ccview.delegate = self;
        
        ccview.adNativeModel = nativeModel;
        
        ccview.titleLable.text = nativeModel.title;
        [self getImageFromURL:nativeModel.icon img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                ccview.iconImage.image = ig;
            });
        }];
        [self getImageFromURL:nativeModel.image img:^(UIImage *ig) {
            dispatch_async(dispatch_get_main_queue(), ^{
                ccview.imageImage.image = ig;
            });
        }];
        
        ccview.descLable.text = nativeModel.desc;
        [ccview.button setTitle:nativeModel.button forState:UIControlStateNormal];
        ccview.starLable.text = [NSString stringWithFormat:@"%f",nativeModel.star];
        ccview.logoImage.image = nativeModel.ADsignImage;
        [self.view addSubview:ccview];
        UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
        btn31.frame = CGRectMake(50, 100, 100, 40);
        btn31.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];;
        [btn31 setTitle:@"关闭" forState:UIControlStateNormal];
        [btn31 addTarget:self action:@selector(closeElement) forControlEvents:UIControlEventTouchUpInside];
        [ccview addSubview:btn31];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = @"One Element 获取成功";
        });
        XPLog(@"One Element 获取成功");
    } failure:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = [NSString stringWithFormat:@"One Element 获取失败，%@",error.description];
        });
        XPLog(@" element:这是怎么回事啊，怎么错啊！%@",error.description);
    }];
}
-(void)closeElement
{
    [ccview removeFromSuperview];
    ccview.adNativeModel = nil;
    ccview = nil;
}

#pragma mark - 获取CT Many Element
- (void)getCTMany_ElementViewController
{
    [self showGetAd];
    @weakify(self)
    CTService *service = [CTService shareManager];
    [service getMultitermNativeADswithSlotId:nativeSlotId adNumbers:2 delegate:service imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES success:^(NSArray *nativeArr) {
        @strongify(self)
        cview = [[CTView alloc]initWithFrame:CGRectMake(30, 30, XPWidth -60, 200)];
        if ([nativeArr isKindOfClass:[NSNull class]] && nativeArr == nil)
        {
            self.hud = [[ZCJHUD alloc] initWithView:self.view];
            [self.view addSubview:self.hud];
            self.hud.labelText = @"返回的广告数据有问题";
            [self.hud show];
            [self performSelector:@selector(done) withObject:nil afterDelay:0.5];
            return ;
        }
        if (nativeArr.count >= 1)
        {
            cview.adNativeModel = [nativeArr objectAtIndex:0];
            cview.delegate = self;
            cview.backgroundColor = [UIColor grayColor];
            [self.view addSubview:cview];
            cview.titleLable.text = cview.adNativeModel.title;
            cview.descLable.text = cview.adNativeModel.desc;
            [cview.button setTitle:cview.adNativeModel.button forState:UIControlStateNormal];
            cview.starLable.text = [NSString stringWithFormat:@"%f",cview.adNativeModel.star];
            cview.logoImage.image = cview.adNativeModel.ADsignImage;
        }
        
        if (nativeArr.count >= 2)
        {
            cview1 = [[CTView alloc]initWithFrame:CGRectMake(30, 250, XPWidth -60, 200)];
            cview1.adNativeModel = [nativeArr objectAtIndex:1];
            cview1.backgroundColor = [UIColor grayColor];
            cview1.delegate = self;
            [self.view addSubview:cview1];
            cview1.titleLable.text = cview1.adNativeModel.title;
            cview1.descLable.text = cview1.adNativeModel.desc;
            [cview1.button setTitle:cview1.adNativeModel.button forState:UIControlStateNormal];             cview1.starLable.text = [NSString stringWithFormat:@"%f",cview1.adNativeModel.star];
            cview1.logoImage.image = cview1.adNativeModel.ADsignImage;
        }
        
        UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
        btn31.frame = CGRectMake(50, 100, 100, 40);
        btn31.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];;
        [btn31 setTitle:@"关闭" forState:UIControlStateNormal];
        [btn31 addTarget:self action:@selector(closeMuttilElement) forControlEvents:UIControlEventTouchUpInside];
        [cview addSubview:btn31];
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = @"Many Element 获取成功";
        });
        XPLog(@"Many Element 获取成功");
    }  failure:^(NSError *error) {
        dispatch_async(dispatch_get_main_queue(), ^{
            self.descLable.text = [NSString stringWithFormat:@"Many Element 获取失败，%@",error.description];
        });
        XPLog(@" MultitermElement:这是怎么回事啊，怎么错啊！%@",error.description);
    }];
}
-(void)closeMuttilElement
{
    [cview removeFromSuperview];
    cview.adNativeModel = nil;
    cview = nil;
    [cview1 removeFromSuperview];
    cview1.adNativeModel = nil;
    cview1 = nil;
}
#pragma mark - 图片加载方法
-(void) getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}

- (void)done
{
    [self.hud hide];
}
- (void)showGetAd
{
    self.hud = [[ZCJHUD alloc] initWithView:self.view];
    [self.view addSubview:self.hud];
    self.hud.labelText = @"点击按钮，正在加载！";
    [self.hud show];
    [self performSelector:@selector(done) withObject:nil afterDelay:0.5];
}
- (void)CTNativeAdJumpfail:(UIView *)nativeAd
{
    NSLog(@"跳转失败了");
}


@end
