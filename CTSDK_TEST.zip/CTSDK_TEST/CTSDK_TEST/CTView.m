

#import "CTView.h"
@implementation CTView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.backgroundColor = [UIColor grayColor];
        self.logoImage = [[UIImageView alloc]initWithFrame:CGRectMake(frame.size.width - 16, 0, 16, 16)];
        self.titleLable = [[UILabel alloc]initWithFrame:CGRectMake(50, 0, frame.size.width-65, 50)];
        self.iconImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 50, 50)];
        self.imageImage = [[UIImageView alloc]initWithFrame:CGRectMake(0, 50, frame.size.width, 120)];
        self.descLable = [[UILabel alloc]initWithFrame:CGRectMake(0, 170, frame.size.width/2.0, 30)];
        self.button = [UIButton buttonWithType:UIButtonTypeCustom];
        self.button.frame = CGRectMake(frame.size.width/2.0, 170, frame.size.width/2.0, 30);
        [self.button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        [self addSubview:self.logoImage];
        [self addSubview:self.titleLable];
        [self addSubview:self.iconImage];
        [self addSubview:self.imageImage];
        [self addSubview:self.descLable];
        [self addSubview:self.button];
    }
    return self;
}

@end
