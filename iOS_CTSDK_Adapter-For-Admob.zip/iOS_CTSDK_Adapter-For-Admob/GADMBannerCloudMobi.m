//
//  GADMBannerCloudMobi.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/15.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMBannerCloudMobi.h"
#import <CTSDK/CTSDK.h>
@implementation GADMBannerCloudMobi
@synthesize delegate;


- (void)requestBannerAd:(GADAdSize)adSize parameter:(NSString * _Nullable)serverParameter label:(NSString * _Nullable)serverLabel request:(nonnull GADCustomEventRequest *)request {
    NSLog(@"-----条幅%@ %@  %@",serverParameter,serverLabel,NSStringFromCGSize(adSize.size));
    [[CTService shareManager] loadRequestGetCTSDKConfigBySlot_id:serverParameter];
    [[CTService shareManager] getBannerADswithSlotId:serverParameter delegate:self frame:CGRectMake(0, 0, adSize.size.width, adSize.size.height) needCloseButton:YES isTest:YES success:^(UIView *bannerView) {
        [self.delegate customEventBanner:self didReceiveAd:bannerView];
    } failure:^(NSError *error) {
        [self.delegate customEventBanner:self didFailAd:error];
    }];
}

/**
 * User click the advertisement.
 */
-(void)CTNativeAdDidClick:(UIView *)nativeAd
{
    [self.delegate customEventBannerWasClicked:self];
}
/**
 * Advertisement landing page will show.
 */
-(void)CTNativeAdDidIntoLandingPage:(UIView *)nativeAd
{
    [self.delegate customEventBannerWillPresentModal:self];
}
/**
 * User left the advertisement landing page.
 */
-(void)CTNativeAdDidLeaveLandingPage:(UIView *)nativeAd
{
    [self.delegate customEventBannerDidDismissModal:self];
}
/**
 * Leave App
 */
-(void)CTNativeAdWillLeaveApplication:(UIView *)nativeAd
{
    [self.delegate customEventBannerWillLeaveApplication:self];
}
/**
 * Jump failure
 */
-(void)CTNativeAdJumpfail:(UIView*)nativeAd
{
    
}

@end
