//
//  GADMBannerCloudMobi.h
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/15.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import <Foundation/Foundation.h>
@import GoogleMobileAds;
@interface GADMBannerCloudMobi : NSObject <GADCustomEventBanner>

@end
