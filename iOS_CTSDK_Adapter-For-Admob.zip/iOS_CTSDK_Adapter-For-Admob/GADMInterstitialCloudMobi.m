//
//  GADMInterstitialCloudMobi.m
//  GPADMOB
//
//  Created by 兰旭平 on 2017/11/14.
//  Copyright © 2017年 MySDK.com. All rights reserved.
//

#import "GADMInterstitialCloudMobi.h"
#import <CTSDK/CTSDK.h>
@import GoogleMobileAds;
@interface GADMInterstitialCloudMobi () <GADCustomEventInterstitial>

@end

@implementation GADMInterstitialCloudMobi

#pragma mark GADCustomEventInterstitial implementation
@synthesize delegate;
- (void)requestInterstitialAdWithParameter:(NSString *)serverParameter
                                     label:(NSString *)serverLabel
                                   request:(GADCustomEventRequest *)request {
    NSLog(@"-----插屏%@ %@",serverParameter,serverLabel);
    [[CTService shareManager] loadRequestGetCTSDKConfigBySlot_id:serverParameter];
    [[CTService shareManager] preloadInterstitialWithSlotId:serverParameter delegate:serverLabel isFullScreen:YES isTest:YES success:^(UIView *InterstitialView) {
         [self.delegate customEventInterstitialDidReceiveAd:self];
    } failure:^(NSError *error) {
        [self.delegate customEventInterstitial:self didFailAd:error];
    }];
}

/// Present the interstitial ad as a modal view using the provided view controller.
- (void)presentFromRootViewController:(UIViewController *)rootViewController {
   
    [[CTService shareManager] interstitialShowWithControllerStyle];
}

#pragma mark - Delegate
-(void)CTInterstitialDidClick:(CTInterstitial*)interstitial
{
    [self.delegate customEventInterstitialWasClicked:self];
}

-(void)CTInterstitialDidIntoLandingPage:(CTInterstitial*)interstitial
{
    [self.delegate customEventInterstitialWillPresent:self];
}

-(void)CTInterstitialDidLeaveLandingPage:(CTInterstitial*)interstitial
{
    [self.delegate customEventInterstitialWillDismiss:self];
}

-(void)CTInterstitialClosed:(CTInterstitial*)interstitial
{
    [self.delegate customEventInterstitialWillDismiss:self];
    
}

-(void)CTInterstitialWillLeaveApplication:(CTInterstitial*)interstitial
{
    
    [self.delegate customEventInterstitialWillLeaveApplication:self];
    
}
- (void)CTInterstitialJumpfail:(CTInterstitial *)interstitialAD
{

}

@end
