//
//  ViewController.m
//  testUnity
//
//  Created by Mirinda on 17/8/7.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "ViewController.h"
#import "UnityAds/UnityAds.h"

@interface ViewController ()<UnityAdsDelegate>
@property(nonatomic,strong)UIButton* btn;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [UnityAds initialize:@"1500015" delegate:self];
    self.btn = [UIButton buttonWithType:UIButtonTypeRoundedRect];
    self.btn.frame = CGRectMake(20, 500, 150, 35);
    
    [self.btn setTitle:@"Show AD" forState:UIControlStateNormal];
    [self.btn setTitle:@"Show AD" forState:UIControlStateHighlighted];
    [self.btn addTarget:self action:@selector(okokok) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:self.btn];
    self.btn.hidden = YES;
    // Do any additional setup after loading the view, typically from a nib.
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(void)okokok
{
    [UnityAds show:self placementId:@"rewardedVideo"];
}

- (void)unityAdsReady:(NSString *)placementId{
    self.btn.hidden = NO;
}

- (void)unityAdsDidError:(UnityAdsError)error withMessage:(NSString *)message{
}

- (void)unityAdsDidStart:(NSString *)placementId{
}

- (void)unityAdsDidFinish:(NSString *)placementId withFinishState:(UnityAdsFinishState)state{
}
@end
