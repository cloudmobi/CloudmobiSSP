//
//  MPNativeAdPlacerCollectionViewController.h
//  MoPub
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>
@class MPAdInfo;

@interface MPNativeAdPlacerCollectionViewController : UICollectionViewController

- (id)initWithAdInfo:(MPAdInfo *)info;

@end
