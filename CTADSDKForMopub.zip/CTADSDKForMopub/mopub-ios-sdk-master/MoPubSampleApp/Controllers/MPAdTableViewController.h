//
//  MPAdTableViewController.h
//  MoPub
//
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MPAdTableViewController : UITableViewController

- (id)initWithAdSections:(NSArray *)sections;

@end
