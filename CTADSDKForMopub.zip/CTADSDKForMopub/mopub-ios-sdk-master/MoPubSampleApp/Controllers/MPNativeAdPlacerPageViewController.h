//
//  MPNativeAdPlacerPageViewController.h
//  MoPubSampleApp
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MPAdInfo;

@interface MPNativeAdPlacerPageViewController : UIViewController

- (instancetype)initWithAdInfo:(MPAdInfo *)info;

@end
