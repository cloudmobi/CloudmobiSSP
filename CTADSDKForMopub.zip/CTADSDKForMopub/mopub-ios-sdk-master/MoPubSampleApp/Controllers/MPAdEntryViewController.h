//
//  MPAdEntryViewController.h
//  MoPubSampleApp
//
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>

@class MPAdInfo;

@interface MPAdEntryViewController : UIViewController

- (id)initWithAdInfo:(MPAdInfo *)adInfo;

@end
