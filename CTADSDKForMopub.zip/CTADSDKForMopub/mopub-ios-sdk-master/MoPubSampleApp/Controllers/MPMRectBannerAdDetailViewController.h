//
//  MPMRectBannerAdDetailViewController.h
//  MoPub
//
//  Copyright (c) 2013 MoPub. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MPBannerAdDetailViewController.h"

@interface MPMRectBannerAdDetailViewController : MPBannerAdDetailViewController

@end
