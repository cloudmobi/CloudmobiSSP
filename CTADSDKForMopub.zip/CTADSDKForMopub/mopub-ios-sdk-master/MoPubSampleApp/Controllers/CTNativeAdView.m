//
//  CTNativeAdView.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/12.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "CTNativeAdView.h"

@implementation CTNativeAdView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
