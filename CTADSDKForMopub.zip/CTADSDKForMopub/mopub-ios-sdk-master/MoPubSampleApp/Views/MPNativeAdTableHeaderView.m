//
//  MPNativeAdTableHeaderView.m
//  MoPub
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import "MPNativeAdTableHeaderView.h"

@implementation MPNativeAdTableHeaderView

@end
