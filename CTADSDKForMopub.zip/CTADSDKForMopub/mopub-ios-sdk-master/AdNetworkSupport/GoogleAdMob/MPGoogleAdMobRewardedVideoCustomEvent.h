#import "MPRewardedVideoCustomEvent.h"

/*
 * Please reference the Supported Mediation Partner page at http://bit.ly/2mqsuFH for the
 * latest version and ad format certifications.
 */
@interface MPGoogleAdMobRewardedVideoCustomEvent : MPRewardedVideoCustomEvent

@end
