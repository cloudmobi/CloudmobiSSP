#import "TapjoyGlobalMediationSettings.h"

@implementation TapjoyGlobalMediationSettings

@end
