//
//  AdColonyInstanceMediationSettings.m
//  MoPubSDK
//
//  Copyright (c) 2016 MoPub. All rights reserved.
//

#import "AdColonyInstanceMediationSettings.h"

@implementation AdColonyInstanceMediationSettings

@end
