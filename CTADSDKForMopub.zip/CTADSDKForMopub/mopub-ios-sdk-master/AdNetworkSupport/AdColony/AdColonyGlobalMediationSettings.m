//
//  AdColonyGlobalMediationSettings.m
//  MoPubSDK
//
//  Copyright (c) 2016 MoPub. All rights reserved.
//

#import "AdColonyGlobalMediationSettings.h"

@implementation AdColonyGlobalMediationSettings

@end
