//
//  CTADRewardedVideoCustomEvent.m
//  AppstoreCtl
//
//  Created by Mirinda on 2017/11/15.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "CTADRewardedVideoCustomEvent.h"

@implementation CTADRewardedVideoCustomEvent

@end
