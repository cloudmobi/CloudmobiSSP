//
//  UnityAdsInstanceMediationSettings.m
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "UnityAdsInstanceMediationSettings.h"

@implementation UnityAdsInstanceMediationSettings

@end
