//
//  MPVASTResource.m
//  MoPub
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPVASTResource.h"

@implementation MPVASTResource

+ (NSDictionary *)modelMap
{
    return @{@"content":            @"text",
             @"staticCreativeType": @"creativeType"};
}

@end
