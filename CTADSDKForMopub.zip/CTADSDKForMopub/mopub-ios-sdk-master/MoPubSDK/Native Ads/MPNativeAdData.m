//
//  MPNativeAdData.m
//  MoPub
//
//  Copyright (c) 2014 MoPub. All rights reserved.
//

#import "MPNativeAdData.h"

@implementation MPNativeAdData

@end
