//
//  MPCollectionViewAdPlacerCell.m
//  MoPubSDK
//
//  Copyright (c) 2015 MoPub. All rights reserved.
//

#import "MPCollectionViewAdPlacerCell.h"

@implementation MPCollectionViewAdPlacerCell

@end
