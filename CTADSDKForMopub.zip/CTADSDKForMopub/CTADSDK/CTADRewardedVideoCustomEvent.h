//
//  CTADRewardedVideoCustomEvent.h
//  AppstoreCtl
//
//  Created by Mirinda on 2017/11/15.
//  Copyright © 2017年 Mirinda. All rights reserved.
//


#import "MPRewardedVideoCustomEvent.h"


@interface CTADRewardedVideoCustomEvent : MPRewardedVideoCustomEvent

@end



