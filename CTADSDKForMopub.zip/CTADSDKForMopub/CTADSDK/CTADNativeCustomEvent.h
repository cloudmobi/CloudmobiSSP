//
//  MPCTADNativeCustomEvent.h
//  GoldMedal
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "MPNativeCustomEvent.h"

@interface CTADNativeCustomEvent : MPNativeCustomEvent

@end
