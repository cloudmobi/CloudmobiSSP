//
//  CTADInterstitialCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/10.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "CTADInterstitialCustomEvent.h"
#import <CTSDK/CTSDK.h>

@implementation CTADInterstitialCustomEvent

- (void)requestInterstitialWithCustomEventInfo:(NSDictionary *)info
{
    CTService* manager = [CTService shareManager];
    [manager loadRequestGetCTSDKConfigBySlot_id:@"262"];
    [manager preloadInterstitialWithSlotId:@"262" delegate:self isFullScreen:YES isTest:NO success:^(UIView *InterstitialView) {
        [self.delegate interstitialCustomEvent:self didLoadAd:InterstitialView];

    } failure:^(NSError *error) {
        [self.delegate interstitialCustomEvent:self didFailToLoadAdWithError:error];
        
    }];
}


- (void)showInterstitialFromRootViewController:(UIViewController *)rootViewController
{
    CTService* manager = [CTService shareManager];
    [manager interstitialShowWithControllerStyle];
    [self.delegate trackImpression];
}

- (void)dealloc
{
    
}

#pragma mark FBInterstitialAdDelegate methods
-(void)CTInterstitialDidClick:(CTInterstitial*)interstitialAD
{
    [self.delegate trackClick];
    [self.delegate interstitialCustomEventDidReceiveTapEvent:self];
}

-(void)CTInterstitialClosed:(CTInterstitial*)interstitialAD;
{
    [self.delegate interstitialCustomEventDidDisappear:self];
}

-(void)CTInterstitialWillLeaveApplication:(CTInterstitial*)interstitialAD;

{
    [self.delegate interstitialCustomEventWillDisappear:self];
}

@end
