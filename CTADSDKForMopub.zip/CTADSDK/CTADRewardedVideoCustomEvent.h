//
//  CTADRewardedVideoCustomEvent.h
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/12.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "MPRewardedVideoCustomEvent.h"


@interface CTADRewardedVideoCustomEvent : MPRewardedVideoCustomEvent

@end
