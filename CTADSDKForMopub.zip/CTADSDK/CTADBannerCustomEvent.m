//
//  CTADBannerCustomEvent.m
//  MoPubSampleApp
//
//  Created by Mirinda on 17/7/7.
//  Copyright © 2017年 MoPub. All rights reserved.
//

#import "CTADBannerCustomEvent.h"
#import <CTSDK/CTSDK.h>

@interface CTADBannerCustomEvent()
@property (nonatomic,strong)CTBanner* ctBanner;
@end

@implementation CTADBannerCustomEvent


- (BOOL)enableAutomaticImpressionAndClickTracking
{
    return NO;
}

- (void)requestAdWithSize:(CGSize)size customEventInfo:(NSDictionary *)info
{
    CTService* manager = [CTService shareManager];
    [manager loadRequestGetCTSDKConfigBySlot_id:@"260"];
    [manager getBannerADswithSlotId:@"260" delegate:self frame:CGRectMake(0, 0, 320, 50) needCloseButton:YES isTest:NO success:^(UIView *bannerView) {
        self.ctBanner =(CTBanner*)bannerView;
        [self.delegate bannerCustomEvent:self didLoadAd:bannerView];
        [self.delegate trackImpression];
    } failure:^(NSError *error) {
        [self.delegate bannerCustomEvent:self didFailToLoadAdWithError:error];
    }];
}

- (void)dealloc
{
    if (self.ctBanner)
    {
        [(UIView*)self.ctBanner removeFromSuperview];
    }
}

#pragma mark FBAdViewDelegate methods
-(void)CTBannerDidClick:(CTBanner*)banner
{
    [self.delegate trackClick];
    [self.delegate bannerCustomEventWillBeginAction:self];
}


-(void)CTBannerWillLeaveApplication:(CTBanner*)banner
{
    [self.delegate bannerCustomEventWillLeaveApplication:self];
}

@end
