###<a name="install">CTSDK For Mopub</a>

  NativeAd 说明：
  向mopub框架提供的NativeAdView 需要继承 CTNativeAd 并且dealloc 方法添加如下代码：
        
        [self removeObserver:self forKeyPath:@"adNativeModel"];
  

