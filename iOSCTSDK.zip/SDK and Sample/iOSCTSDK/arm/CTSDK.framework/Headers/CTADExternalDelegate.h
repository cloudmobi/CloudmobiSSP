//
//  CTIntersitialPrivate.h
//  CTSDK
//
//  Created by Mirinda on 16/7/26.
//  Copyright © 2016年 YeahMobi. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CTInterstitial;
@class CTNative;
@class CTBanner;
@class CTElement;

@protocol CTInterstitialDelegate <NSObject>
#pragma mark Interstitial Interaction Notifications

@optional
-(void)CTInterstitialDidClick:(CTInterstitial*)interstitialAD;

-(void)CTInterstitialDidIntoLandingPage:(CTInterstitial*)interstitialAD;

-(void)CTInterstitialDidLeaveLandingPage:(CTInterstitial*)interstitialAD;

-(void)CTInterstitialClosed:(CTInterstitial*)interstitialAD;

-(void)CTInterstitialWillLeaveApplication:(CTInterstitial*)interstitialAD;

@end


@protocol CTNativeDelegate <NSObject>

#pragma mark Interstitial Native Notifications
@optional
-(void)CTNativeDidClick:(CTNative*)native;

-(void)CTNativeDidIntoLandingPage:(CTNative*)native;

-(void)CTNativeDidLeaveLandingPage:(CTNative*)native;

-(void)CTNativeClosed:(CTNative*)native;

-(void)CTNativeWillLeaveApplication:(CTNative*)native;

-(void)CTNativeHtml5Closed:(CTNative*)native;
@end


#pragma mark Banner delegate

@protocol CTBannerDelegate <NSObject>

@optional
-(void)CTBannerDidClick:(CTBanner*)banner;

-(void)CTBannerDidIntoLandingPage:(CTBanner*)banner;

-(void)CTBannerDidLeaveLandingPage:(CTBanner*)banner;

-(void)CTBannerClosed:(CTBanner*)banner;

-(void)CTBannerWillLeaveApplication:(CTBanner*)banner;

-(void)CTBannerHtml5Closed:(CTBanner*)banner;
@end

#pragma mark ElementAd Delegate

@protocol CTElementAdDelegate <NSObject>

@optional
-(void)CTElementAdDidClick:(CTElement *)ElementAd;

-(void)CTElementAdDidIntoLandingPage:(CTElement *)ElementAd;

-(void)CTElementAdDidLeaveLandingPage:(CTElement *)ElementAd;

-(void)CTElementAdClosed:(CTElement *)ElementAd;

-(void)CTElementAdWillLeaveApplication:(CTElement *)ElementAd;

-(void)CTElementAdHtml5Closed:(CTElement *)ElementAd;
@end

