//
//  MessageBird.m
//  CTSDK_iOS
//
//  Created by 兰旭平 on 16/8/24.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import "MessageBird.h"

@implementation MessageBird
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        
        [self addSubview:self.imageView];
        _lable1 = [[UILabel alloc]initWithFrame:CGRectMake(80, 15, 150, 16)];
        _lable1.text = @"This is title";
        [self addSubview:_lable1];
        _lable2 = [[UILabel alloc]initWithFrame:CGRectMake(80, 32, 200, 50)];
        _lable2.text = @"Message Bird Detail text ! Message Bird Detail text !";
        _lable2.numberOfLines = 3;
        [self addSubview:_lable2];
        _imageview2 = [[UIImageView alloc]initWithFrame:CGRectMake(frame.size.width- 45, 35, 30, 30)];
        _imageview2.image = [UIImage imageNamed:@"10.png"];
        [self addSubview:_imageview2];
    }
    return self;
}
- (UIImageView *)imageView
{
    if (!_imageView) {
        _imageView = [[UIImageView alloc]initWithFrame:CGRectMake(15, 15, 50, 50)];
        _imageView.layer.masksToBounds = YES;
        _imageView.layer.cornerRadius = 50 /2.0;
        _imageView.layer.borderColor = [[UIColor grayColor] CGColor];
        _imageView.layer.borderWidth = 1.0f;
    }
    return _imageView;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
