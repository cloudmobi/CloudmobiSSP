//
//  ViewController.m
//  MessageBird
//
//  Created by 兰旭平 on 16/8/24.
//  Copyright © 2016年 lxp. All rights reserved.
//

#import "ViewController.h"
#import "MessageBird.h"
#import <CTSDK/CTService.h>
@interface ViewController ()<UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, strong)UITableView *tableView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.backgroundColor = [UIColor clearColor];

    // Do any additional setup after loading the view, typically from a nib.
}
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, [UIScreen mainScreen].bounds.size.height ) style:UITableViewStylePlain];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"Cell"];
        [self.view addSubview:_tableView];
    }
    return _tableView;
}
#pragma mark - Table view data source
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    float height = [UIScreen mainScreen].bounds.size.width /3.6 -1;
    return height + 2;
}
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 10;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Cell" forIndexPath:indexPath];
    if (indexPath.row == 4) {
        [CTService getNativeADswithSlotId:@"40" fbId:@"119578928469786_119603761800636" admobId:nil delegate:self frame:CGRectMake(15, 0, [UIScreen mainScreen].bounds.size.width - 30, [UIScreen mainScreen].bounds.size.width/3.6) needCloseButton:NO keyWords:nil isTest:NO success:^(UIView *NativeView) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [cell addSubview:NativeView];
            });
        } failure:^(NSError *error) {
            NSLog(@"failed %@", error.description);
        }];
    }else{
        MessageBird *mv = [[MessageBird alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, [UIScreen mainScreen].bounds.size.width - 30/3.6)];
        NSInteger m = indexPath.row;
        if (m >= 3) {
            m = m -3;
        }
        mv.imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%ld.jpg",m]];
        [cell addSubview:mv];
    }
    return cell;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
