//
//  MessageBird.h
//  CTSDK_iOS
//
//  Created by 兰旭平 on 16/8/24.
//  Copyright © 2016年 Mirinda. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageBird : UIView
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UILabel *lable1;
@property(nonatomic,strong)UILabel *lable2;
@property(nonatomic,strong)UIImageView *imageview2;
@end
