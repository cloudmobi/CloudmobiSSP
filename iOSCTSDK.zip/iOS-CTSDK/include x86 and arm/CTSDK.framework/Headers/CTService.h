//
//  CTManager.h
//  CTSDK
//
//  Created by Mirinda on 16/6/15.
//  Copyright © 2016年 YeahMobi. All rights reserved.
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@class CTBanner;
@class CTInterstitial;
@class CTNative;

@interface CTService : NSObject

//Interstitial AD inferface
//Preload Interstitial
+(void)preloadInterstitialWithSlotId:(NSString*)slot_id
                                fbId:(NSString*)fb_id
                             admobId:(NSString*)mob_id
                            delegate:(id)delegate
                              isTest:(BOOL)isTest
                             success:(void (^)(UIView* InterstitialView))success
                             failure:(void (^)(NSError *error))failure;
//Interstitial Show
+(BOOL)interstitialShow;

//Interstitial Close
+(BOOL)interstitialClose;


//Native AD Interface
+(void)getNativeADswithSlotId:(NSString*)slot_id
                         fbId:(NSString*)fb_id
                      admobId:(NSString*)mob_id
                     delegate:(id)delegate
                        frame:(CGRect)frame
              needCloseButton:(BOOL)isNeedBtn
                       isTest:(BOOL)isTest
                      success:(void (^)(UIView* NativeView))success
                      failure:(void (^)(NSError *error))failure;



//Banner AD Interface
+(void)getBannerADswithSlotId:(NSString*)slot_id
                         fbId:(NSString*)fb_id
                      admobId:(NSString*)mob_id
                     delegate:(id)delegate
                        frame:(CGRect)frame
              needCloseButton:(BOOL)isNeedBtn
                       isTest:(BOOL)isTest
                      success:(void (^)(UIView* bannerView))success
                      failure:(void (^)(NSError *error))failure;

@end


//@protocol CTServiceDelegate <NSObject>
//
//@optional
////banner
//- (void)CTServiceBannerDidClickAd:(CTBanner *)banner;
//- (void)CTServiceBannerDidClosedAd:(CTBanner *)banner;
//- (void)CTServiceBannerDidOpenLandingPage:(CTBanner *)banner;
//- (void)CTServiceBannerDidCloseLandingPage:(CTBanner *)banner;
//
////interstitial
//- (void)CTServiceInterstitialDidClickAd:(CTInterstitial *)interstitial;
//- (void)CTServiceInterstitialDidClosedAd:(CTInterstitial *)interstitial;
//- (void)CTServiceInterstitialDidOpenLandingPage:(CTInterstitial *)interstitial;
//- (void)CTServiceInterstitialDidCloseLandingPage:(CTInterstitial *)interstitial;
//
////native
//- (void)CTServiceNativeDidClickAd:(CTNative *)native;
//- (void)CTServiceNativeDidClosedAd:(CTNative *)native;
//- (void)CTServiceNativeDidOpenLandingPage:(CTNative *)native;
//- (void)CTServiceNativeDidCloseLandingPage:(CTNative *)native;
//
//@end