//
//  RewardVideoViewController.m
//  CTSDK_iOS
//
//  Created by 兰旭平 on 2017/3/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "RewardVideoViewController.h"
#import <CTSDK/CTService.h>
#import <CTSDK/CTRewardVideoDelegate.h>
#import "Tools.h"
@interface RewardVideoViewController ()<CTRewardVideoDelegate>
@property (nonatomic, strong) UIButton *loadButton;
@property (nonatomic, strong) UIButton *showAdButton;
@end

@implementation RewardVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    [self setUILayout];
}

- (void)setUILayout
{
    self.loadButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.loadButton.backgroundColor = [UIColor brownColor];
    self.loadButton.frame = CGRectMake(0, XPHeight - kButtonHeight, XPWidth / 2.0, kButtonHeight);
    [self.loadButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.loadButton setTitle:[NSString stringWithFormat:@"Load Ad"] forState:UIControlStateNormal];
    [self.view addSubview:self.loadButton];
    [self.loadButton addTarget:self action:@selector(loadRewardVideo) forControlEvents:UIControlEventTouchUpInside];
    
    self.showAdButton = [UIButton buttonWithType:UIButtonTypeCustom];
    self.showAdButton.backgroundColor = [UIColor orangeColor];
    self.showAdButton.frame = CGRectMake(XPWidth / 2.0, XPHeight - kButtonHeight, XPWidth / 2.0, kButtonHeight);
    [self.showAdButton setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [self.showAdButton setTitle:[NSString stringWithFormat:@"Show Ad"] forState:UIControlStateNormal];
    [self.showAdButton addTarget:self action:@selector(showRewardVideo) forControlEvents:UIControlEventTouchUpInside];
    [self setButtonState:self.showAdButton allowToclick:NO];
    [self.view addSubview:self.showAdButton];
    
    UIButton* disMissButton = [UIButton buttonWithType:UIButtonTypeSystem];
    disMissButton.frame = CGRectMake(0, XPHeight - 2 * kButtonHeight, XPWidth, kButtonHeight);
    disMissButton.backgroundColor = [UIColor grayColor];
    [disMissButton setTitle:@"Dismiss ViewController" forState:UIControlStateNormal];
    [disMissButton addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:disMissButton];
}

- (void)showRewardVideo
{
    if ([[CTService shareManager] checkRewardVideoIsReady]) {
        [[CTService shareManager] showRewardVideoWithPresentingViewController:self];
    } else {
        [self setButtonState:self.showAdButton allowToclick:NO];
    }
}
- (void)loadRewardVideo
{
    [self setButtonState:self.loadButton allowToclick:NO];
    [[CTService shareManager] loadRewardVideoWithSlotId:AppWallSlotId delegate:self];
}

- (void)dismiss
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)setButtonState:(UIButton *)button allowToclick:(BOOL)state
{
    if ([NSThread isMainThread]) {
        button.alpha = state ? 1 : 0.3;
        button.userInteractionEnabled = state;
    }else {
        dispatch_sync(dispatch_get_main_queue(), ^{
            button.alpha = state ? 1 : 0.3;
            button.userInteractionEnabled = state;
        });
    }
    
}

#pragma mark - Delegate for RewardVideo (CT)
- (void)CTRewardVideoLoadSuccess
{
    [self setButtonState:self.loadButton allowToclick:NO];
    [self setButtonState:self.showAdButton allowToclick:YES];
    NSLog(@"CTSDK RewardVideo Load Success");
}
- (void)CTRewardVideoDidStartPlaying
{
    NSLog(@"CTSDK RewardVideo Start Playing");
}
- (void)CTRewardVideoDidFinishPlaying
{
    NSLog(@"CTSDK RewardVideo Did Finish Playing");
}
- (void)CTRewardVideoDidClickRewardAd
{
    NSLog(@"CTSDK RewardVideo Did Click RewardVideo Ad");
}
- (void)CTRewardVideoWillLeaveApplication
{
    NSLog(@"CTSDK RewardVideo Will Leave Application");
}
- (void)CTRewardVideoJumpfailed
{
    NSLog(@"CTSDK RewardVideo Jump Appstore failed");
}
- (void)CTRewardVideoLoadingFailed:(NSError *)error
{
    [self setButtonState:self.loadButton allowToclick:YES];
    NSLog(@"CTSDK Error: %@ ",error.description);
}
- (void)CTRewardVideoClosed
{
    [self setButtonState:self.showAdButton allowToclick:NO];
    [self setButtonState:self.loadButton allowToclick:YES];
    NSLog(@"CTSDK RewardVideo Closed AD");
}
- (void)CTRewardVideoAdRewardedName:(NSString *)rewardName rewardAmount:(NSString *)rewardAmount
{
    NSLog(@"CTSDK RewardMessage : [name:%@ amount:%@]",rewardName, rewardAmount);
}
@end

