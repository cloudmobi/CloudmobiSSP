//
//  RewardVideoViewController.m
//  CTSDK_iOS
//
//  Created by 兰旭平 on 2017/3/10.
//  Copyright © 2017年 Mirinda. All rights reserved.
//

#import "RewardVideoViewController.h"
#import <CTSDK/CTService.h>
#import <CTSDK/CTRewardVideoDelegate.h>
#import "Tools.h"
@interface RewardVideoViewController ()<CTRewardVideoDelegate>

@end

@implementation RewardVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    button.backgroundColor = [UIColor colorWithRed:115/255.0 green:74/255.0 blue:18/255.0 alpha:1];
    button.frame = CGRectMake(0, self.view.frame.size.height - 50, self.view.frame.size.width, 50);
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTitle:[NSString stringWithFormat:@"请求RewardVideo并show"] forState:UIControlStateNormal];
    [self.view addSubview:button];
    [button addTarget:self action:@selector(loadRewardVideo) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton* btn31 = [UIButton buttonWithType:UIButtonTypeSystem];
    btn31.frame = CGRectMake(0, self.view.frame.size.height - 100, self.view.frame.size.width, 50);
    btn31.backgroundColor = [UIColor colorWithRed:255/255.0 green:165/255.0 blue:0 alpha:1];
    [btn31 setTitle:@"关闭" forState:UIControlStateNormal];
    [btn31 addTarget:self action:@selector(closeAdView) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:btn31];

}

- (void)loadRewardVideo
{
    [[CTService shareManager] loadRewardVideoWithSlotId:AppWallSlotId delegate:self];
}

- (void)closeAdView
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)CTRewardVideoLoadSuccess
{
    XPLog(@"CTRewardVideoLoadSuccess");
    [[CTService shareManager] showRewardVideo];
}

/**
 *  CTRewardVideo bigin playing Ad
 **/
- (void)CTRewardVideoDidStartPlaying
{
    XPLog(@"CTRewardVideoDidStartPlaying");
}

/**
 *  CTRewardVideo playing Ad finish
 **/
- (void)CTRewardVideoDidFinishPlaying
{
    XPLog(@"CTRewardVideoDidFinishPlaying");
}

/**
 *  CTRewardVideo Click Ads
 **/
- (void)CTRewardVideoDidClickRewardAd
{
    XPLog(@"CTRewardVideoDidClickRewardAd");
}

/**
 * CTRewardVideo will leave Application
 **/
- (void)CTRewardVideoWillLeaveApplication
{
    XPLog(@"CTRewardVideoWillLeaveApplication");
}

/**
 *  CTRewardVideo jump AppStroe failed
 **/
- (void)CTRewardVideoJumpfailed
{
    XPLog(@"CTRewardVideoJumpfailed");
}

/**
 *  CTRewardVideo loading failed
 **/
- (void)CTRewardVideoLoadingFailed:(NSError *)error
{
    XPLog(@"出错了%@",error.description);
}

- (void)CTRewardVideoClosed
{
    XPLog(@"CTRewardVideoClosed");
}

- (void)CTRewardVideoAdRewardedName:(NSString *)rewardName rewardAmount:(NSString *)rewardAmount
{
    XPLog(@"name：%@ amount：%@",rewardName, rewardAmount);
}

@end
