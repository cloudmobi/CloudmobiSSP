//
//  BannerViewController.h
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2016/12/27.
//  Copyright © 2016年 com.algorithms.lxp. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BannerViewController : UIViewController

@end
