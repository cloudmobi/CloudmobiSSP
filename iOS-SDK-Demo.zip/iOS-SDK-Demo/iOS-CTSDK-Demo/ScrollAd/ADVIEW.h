//
//  ADVIEW.h
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2017/3/30.
//  Copyright © 2017年 com.algorithms.lxp. All rights reserved.
//

#import <CTSDK/CTNativeAd.h>

@interface ADVIEW : CTNativeAd
@property (nonatomic, strong)UIImageView *iconImage;
@end
