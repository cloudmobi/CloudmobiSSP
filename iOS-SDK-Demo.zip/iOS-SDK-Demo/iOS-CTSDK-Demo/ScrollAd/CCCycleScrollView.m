//
//  CCCycleScrollView.m
//  CustomCycleScrollView
//

#import "CCCycleScrollView.h"
#import "ADVIEW.h"
#define CC_DEFAULT_DURATION_TIME 5.0f                       //默认持续时间
#define CC_DEFAULT_DURATION_FRAME CGRectMake(0,0,50,50)   //默认frame

@interface CCCycleScrollView ()<UIScrollViewDelegate>

@property (nonatomic, readwrite, strong)ADVIEW * leftIAd;
@property (nonatomic, readwrite, strong)ADVIEW * middleAd;
@property (nonatomic, readwrite, strong)ADVIEW * rightAd;
@property (nonatomic, readwrite, strong)UIScrollView * containerView;
@property (nonatomic, readwrite, strong)NSTimer *timer;
@property NSInteger currentNumber;

@end



@implementation CCCycleScrollView


#pragma mark - init function
- (instancetype)initWithAds:(NSArray *)AdsArr
{
    return [self initWithAds:AdsArr withFrame:CC_DEFAULT_DURATION_FRAME];
}

- (instancetype)initWithAds:(NSArray *)AdsArr withFrame:(CGRect)frame
{
    return [self initWithAds:AdsArr withPageChangeTime:CC_DEFAULT_DURATION_TIME withFrame:frame];
}

- (instancetype)initWithAds:(NSArray *)AdsArr withPageChangeTime:(NSTimeInterval)changeTime withFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        self.frame = frame;
        _AdsArr = [[NSArray alloc]initWithArray:AdsArr];
        _pageChangeTime = changeTime;
        [self cycleViewConfig];
        [self cycleImageViewConfig];
    }
    return self;
}

#pragma mark -init configure
- (void)cycleViewConfig
{
    //设置三个imageview的位置
    //初始化容器ScrollView和三个imageview
    _containerView = [[UIScrollView alloc]initWithFrame:self.bounds];
    _containerView.contentSize = CGSizeMake(3 * _containerView.frame.size.width, 0);
    _containerView.contentOffset = CGPointMake(0, _containerView.frame.origin.y);
    _currentNumber = 0;
    self.leftIAd  = [[ADVIEW alloc]initWithFrame:CGRectMake(0, 0  , _containerView.frame.size.width, _containerView.frame.size.height)];
    self.middleAd = [[ADVIEW alloc]initWithFrame:CGRectMake(_containerView.frame.size.width, 0 , _containerView.frame.size.width, _containerView.frame.size.height)];
    self.rightAd = [[ADVIEW alloc]initWithFrame:CGRectMake(2 * _containerView.frame.size.width, 0, _containerView.frame.size.width, _containerView.frame.size.height)];
    
    _containerView.delegate = self;
    [_containerView addSubview:_leftIAd];
    [_containerView addSubview:_rightAd];
    [_containerView addSubview:_middleAd];
    _containerView.scrollEnabled = YES;
    _containerView.showsHorizontalScrollIndicator = NO;
    _containerView.showsVerticalScrollIndicator = NO;
    _containerView.pagingEnabled = YES;

    [self addSubview:_containerView];
}

- (void)cycleImageViewConfig
{
    if ([_AdsArr count] == 0) {
        NSLog(@"cycleImageViewConfig:images is empty!");
        return;
    }
    _leftIAd.adNativeModel = [self.AdsArr objectAtIndex:0];
    _middleAd.adNativeModel = [self.AdsArr objectAtIndex:1];
    _rightAd.adNativeModel = [self.AdsArr objectAtIndex:2];

    [self getImageFromURL:_leftIAd.adNativeModel.icon img:^(UIImage *ig) {
        dispatch_async(dispatch_get_main_queue(), ^{
            _leftIAd.iconImage.image = ig;
        });
    }];
    [self getImageFromURL:_middleAd.adNativeModel.icon img:^(UIImage *ig) {
        dispatch_async(dispatch_get_main_queue(), ^{
            _middleAd.iconImage.image = ig;
        });
    }];
    [self getImageFromURL:_rightAd.adNativeModel.icon img:^(UIImage *ig) {
        dispatch_async(dispatch_get_main_queue(), ^{
            _rightAd.iconImage.image = ig;
        });
    }];
    
    [self timeSetter];
}

//设置定时器
- (void)timeSetter
{
    //将定时器放入主进程的RunLoop中
    self.timer = [NSTimer timerWithTimeInterval:self.pageChangeTime target:self selector:@selector(timeChanged) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

-(void) getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}
#pragma mark - ScrollView  Delegate
//当用户手动个轮播时 关闭定时器
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    [self.timer invalidate];
}

//当用户手指停止滑动图片时 启动定时器
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate
{
    [self timeSetter];
}

- (void)timeChanged
{
    _currentNumber ++;
    if (_currentNumber >= 3) {
        _currentNumber = 0;
    }
    self.containerView.contentOffset = CGPointMake(_containerView.frame.size.width * _currentNumber, 0);
}

@end
