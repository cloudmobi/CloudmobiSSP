//
//  CCCycleScrollView.h
//  CustomCycleScrollView
//

#import <UIKit/UIKit.h>



@interface CCCycleScrollView : UIView

@property (nonatomic, readwrite, strong)NSArray *AdsArr;
@property (nonatomic, assign)NSTimeInterval  pageChangeTime;


- (instancetype)initWithAds:(NSArray *)AdsArr;
- (instancetype)initWithAds:(NSArray *)AdsArr withFrame:(CGRect)frame;
- (instancetype)initWithAds:(NSArray *)AdsArr withPageChangeTime:(NSTimeInterval)changeTime withFrame:(CGRect)frame;
@end
