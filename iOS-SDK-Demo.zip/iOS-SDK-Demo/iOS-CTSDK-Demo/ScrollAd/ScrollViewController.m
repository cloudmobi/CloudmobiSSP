//
//  ScrollViewController.m
//  iOS-CTSDK-Demo
//
//  Created by 兰旭平 on 2017/3/30.
//  Copyright © 2017年 com.algorithms.lxp. All rights reserved.
//

#import "ScrollViewController.h"
#import "CCCycleScrollView.h"
#import "Tools.h"
#import <CTSDK/CTService.h>
#import "CTView.h"
#import <CTSDK/CTADExternalDelegate.h>
@interface ScrollViewController ()
@property (nonatomic, strong)CCCycleScrollView *cyclePlayView;
@property (nonatomic, strong)CTView *cview;
@property (nonatomic, strong)CTView *cview1;
@end

@implementation ScrollViewController
@synthesize cview;
@synthesize cview1;
- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.automaticallyAdjustsScrollViewInsets = NO;
    @weakify(self)
    CTService *service = [CTService shareManager];
    [service getMultitermNativeADswithSlotId:TwoNativeSlotId adNumbers:5 delegate:service imageWidthHightRate:CTImageWHRateOnePointNineToOne isTest:YES success:^(NSArray *nativeArr) {
        @strongify(self)
        dispatch_async(dispatch_get_main_queue(), ^{
            self.cyclePlayView = [[CCCycleScrollView alloc]initWithAds:nativeArr withFrame:CGRectMake(100, 300, 50, 50)];
            [self.view addSubview:self.cyclePlayView];
        });
    }  failure:^(NSError *error) {
        XPLog(@" MultitermElement:这是怎么回事啊，怎么错啊！%@",error.description);
    }];
    // Do any additional setup after loading the view.
}
-(void) getImageFromURL:(NSString *)fileURL img:(void(^)(UIImage *ig))image
{
    dispatch_async(dispatch_get_global_queue(0, 0), ^{
        UIImage * result;
        NSData * data = [NSData dataWithContentsOfURL:[NSURL URLWithString:fileURL]];
        result = [UIImage imageWithData:data];
        image(result);
    });
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
